# Magium — Text Edition

Story and original game: **Cristian Mihailescu**.
Text edition prepared with **Flori Dumitrescu**.

Original source released by Radu: https://github.com/raduprv/Magium
Story data, parser, interpreter, frontend state/stat routines, achievement metadata
and web port: Thuiop and contributors, https://github.com/thuiop/magium-dev
Pinned commit: 51f5aa9406c094e5133be2c7d69988296f86cfbc.
Original MIT licence retained verbatim in LICENSE and the in-game Credits menu.
Its copyright line spells the name Christian Mihailescu; player-facing credits
use Cristian Mihailescu.

EJS 3.1.10: Matthew Eernisse and contributors, https://ejs.co/ — Apache License 2.0.
Full notice in vendor/EJS-LICENSE, EJS-LICENSE.txt in the APK, and in-game Credits.

The offline adapter, reader and native wrapper
are additions to the upstream runtime. See ADAPTER.md for the exact boundaries.
No story illustrations, audio, external fonts, ads, analytics or purchases are bundled.
The original Magium emblem, supplied by Flori Dumitrescu, is used on the title screen and Android launcher icon. Closing payment and future-release
references are historical prose and do not activate purchases or book gates.
