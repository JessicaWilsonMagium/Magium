# Magium Text 0.2.9 — independent review of saves and game-state integrity

To: Codex · From: Claude (Anthropic) · 22 October 2026
Source reviewed: `text-edition/Magium-Text-Source-v0.2.9.zip` from the repository's `main` branch (README and Verification-v0.2.9.json match 0.2.9 / versionCode 12).
Production source was not modified. All reproductions are separate scripts in `repro/`; trial corrections were applied only to a scratch copy.

## Summary

Four confirmed defects. One of them is serious for player progress.

| # | Severity | Finding | Reproduced |
|---|---|---|---|
| B1 | **High** | Book 2's temporary +3 Hearing boost pushes Hearing above the stat cap. Every save taken in that window is rejected by validation: Continue, named saves, "Load from last checkpoint", Back and backup export all fail. | Yes: model, full Chapter 11 walk, and real UI (jsdom) |
| B2 | Medium | Loading the checkpoint erases the recorded Book 2 and Book 3 starts. "Restart Book N" becomes permanently unavailable for that run. | Yes: model and real UI |
| B3 | Medium (fidelity) | Achievement "Consolation prize" (die more than five times in Book 3 Ch 9) cannot be earned. The death counter is reset by every checkpoint reload. | Yes, compared against Thuiop semantics |
| B4 | Low–Medium | A story-opened Stats screen can be restored without the dialog: after app kill + Continue, or after Back over a confirmed allocation. Every choice then says "Close Stats before continuing." | Yes: model and real UI |

The transactional import, journal recovery and cold-resume round-trips held up under the extra tests I added (details at the end).

Environment: Node 22.22, jsdom 26.1 (from package-lock). I could not run Android, the APK on a device, Play delivery or WebView storage behaviour. Items depending on those are marked unverified.

Line numbers refer to the files as shipped. These files use long single lines, so a function name is given with each line number.

---

## Confirmed bugs

### B1 — High: over-cap Hearing boost makes saves unloadable (Book 2 Ch 10b → Ch 11c)

**Effect on the player.** In `B2-Ch10b-Boost` (choice "Activate the secret code"), and on the alternative route in `B2-Ch11a-Intro`, the story applies `v_hearing +3`. The boost is removed only on entering `B2-Ch11c-Frenzy`. The window is about 50 scenes, which is almost all of Chapter 11, and it includes the Chapter 11 checkpoint. The stat cap is 4 from Book 1 Ch 6, so any player with Hearing ≥ 2 ends up at 5–7. During that window:

* closing the app and pressing **Continue** gives "Invalid saved stat";
* **named saves** made in the window cannot be loaded;
* after any death in Chapter 11, **"Load from last checkpoint"** fails. The remaining choices on the death screen are "Restart game", which restarts Book 1, or an older save;
* **Back** fails, because every rewind record in the window is over cap;
* **backup export** fails for all saves while any one record is over cap. The autosave alone is enough.

After a failed Continue, a player who taps New Game overwrites the autosave. Nothing else is destroyed: the rejected records stay in storage and become loadable again once validation is relaxed.

Preconditions are ordinary choices: `v_b2_ch6_stat=1`, `v_b2_ch9_channel=1`, `v_ch11_saved_rose=0`, the code activated, and Hearing ≥ 2. Every route to Book 3 passes `B2-Ch11c-Frenzy` (graph check, `boost-window.cjs`), so the boost does not leak into Book 3 saves.

**Where.**
* `src/engine.js` line 42, `restore()`: `if(!Number.isInteger(n)||n<0||n>cap)throw Error('Invalid saved stat')`
* `src/backup.js` line 22, `validateRecord()`: the same `n>cap` rule. Export calls `parse()` from `create()` at line 54, so one bad record blocks the whole export.
* Story data that applies the boost (unchanged and correct): `vendor/thuiop/data/en/b2ch10b.magium:1540–1541`, `b2ch11a.magium:5–6`, `b2ch11c.magium:909–910`.

**Reproduction.** `r5-hearing-boost.cjs` and `r5b-window.cjs`, confirmed through the UI by `app-level.cjs`:
1. Take the Ch 10 start fixture and set the three earlier-choice flags above with Hearing = 2. From there, use real play only.
2. Follow visible choices to `B2-Ch10b-Secret` and choose "Activate the secret code". Hearing becomes 5 and the cap is 4.
3. Create a fresh model on the same storage and call `load('-auto')`.

* Expected: the run resumes.
* Actual: `Invalid saved stat`. Slot load and checkpoint load give the same error, Back gives the same error, and export gives `Invalid saved stats.` With Hearing = 1 the result is 4/4, which loads correctly.

**Why the existing tests missed it.** The differential report's own scope says "Snapshot validation skips synthetic inputs with impossible stat values". This defect is exactly that class of state. It is an adapter-only defect: Thuiop's runtime has no such validation.

**Proposed correction.** Keep the cap for allocation, which is enforced separately in `engine.invest()` line 32 and in the Stats UI. Relax the restore and backup bound to `n <= cap + 3`, or to a fixed sane maximum such as 10, in both places. The trial change in `trial-corrections.diff` makes all B1 reproductions pass. All existing checks still pass except test 21, the 0.2.0 byte-identity pin, which is expected to change. `backup-rejection-check` (999, −1, 1.5) still rejects.

**Compatibility.** The change only loosens validation. No migration is needed, and previously rejected saves load again. The Stats screen will show "5 / 4" during the boost, which matches the story.

### B2 — Medium: checkpoint load erases book-start records

**Effect.** `load()` keeps the Book 2 and Book 3 start records only for `-auto` or for records that carry `bookStarts`. Checkpoint records are bare snapshots, so loading one deletes both start records. This happens through the in-story death button and through Menu → Load checkpoint. "Restart Book 2/3" is then disabled, or fails with "This save has no recorded book start. Use a named save or test chapter start." The message mentions test chapter starts, which do not exist in the public build.

The start records are written again only when the player is on the book's Chapter 1 intro at page 0 (`capture()`), so the loss is permanent for that run. Named saves made afterwards also store `bookStarts: {2:null,3:null}`.

**Where.** `src/model.js` line 19, `load()`: `else if(suffix!=='-auto')for(const b of [2,3])storage.removeItem(...)`. The in-story path goes through line 23, `choose()` → `load('-checkpoint')`. The menu path is `src/app.js` line 28. `restartBook()` is at line 30.

**Reproduction.** `r2-bookstart.cjs` and `app-level.cjs`:
1. Enter Book 2 and then Book 3, which records both starts.
2. Continue to B3 Ch 9 and die.
3. Choose "Load from last checkpoint".

* Expected: both starts are kept and "Restart Book 3" still works.
* Actual: both records are deleted and Restart fails.

The same happens in Book 2 with a checkpoint after Chapter 1. If the checkpoint is exactly at the Chapter 1 intro, `capture()` hides the problem by recording the start again.

**Proposed correction (minimal).** Treat `-checkpoint` like `-auto`: `else if(suffix!=='-auto'&&suffix!=='-checkpoint')`. The trial copy passes. The legacy single save `-manual` still clears the starts, which matches the documented policy.

**Compatibility.** No format change. Interaction with C1 below: if a checkpoint comes from a different run, the kept book starts would belong to the run the player loaded instead. That is no worse than today, where the player loses them entirely.

**Recovery for players already affected (optional).** `-chapter-starts` holds the latest `B2-Ch01a-Intro` and `B3-Ch01a-Intro` snapshots. These could be offered as a restart source, but only with a confirmation, because they may come from another run.

### B3 — Medium (original-behaviour fidelity): "Consolation prize" cannot be earned

**Effect.** In Book 3 Ch 9, `v_ac_b3_ch9_consolation` is incremented at 21 points, mostly on the choice that leads into a death scene. Those death scenes offer only Restart, Load checkpoint or Load game.

In Thuiop's runtime the counter lives in the separate `achievements` store, which `loadGameFromLocalStorage('checkpoint')` never touches. The counter therefore accumulates, and at 5 it sets `v_ac_b3_ch9_prize = 1`. In the adapter all `v_ac_*` values belong to the run snapshot, so each checkpoint reload resets the counter to the checkpoint's value. The counter can never reach 5. Back also undoes it, which is reasonable.

**Where.** `src/model.js` line 19 (`load`) and line 23 (`checkpoint_load` branch). `src/engine.js` line 48, where `restore()` replaces the whole bridge. The counter shim is `src/original-runtime.js` line 602. Upstream behaviour: `vendor/thuiop/public/scripts/utils.js` (`storeItem`/`storeVariable`) and upstream `public/scripts/saves.js` at the pinned commit, where the checkpoint copies only `currentState`.

**Reproduction.** `r1-consolation.cjs`:
1. Start at B3 Ch 9 with the chapter-start checkpoint.
2. Six times: Intro2 → … → Warning → "Attempt to breathe." (death), then "Load from last checkpoint".

* Adapter: the counter is 1 at every death and the prize is never earned.
* Reference simulation with Thuiop's two-store semantics: the counter reaches 6 and the prize is shown.

The existing test (`release.cjs` line 25) increments the counter five times on one bridge and never reloads in between.

**Proposed correction.** Treat this one counter as Thuiop does: global, and not reverted by loads. For example, in `load()`/`jump()`, carry forward `max(live, saved)` of `v_ac_b3_ch9_consolation` into the restored state's `vars` and `upstream.awards` together, so `restore()` does not take the "changed → refresh" path. A small engine helper is the cleanest way to do this.

This is an adapter policy choice. Please confirm the intended semantics with Flori. "Same chapter" in the caption suggests the counter could also be reset when entering Ch 9. Story data stays untouched. No save format change is needed.

### B4 — Low–Medium: pending story Stats restored without its dialog

**Effect.** The Stats choice that every player meets in Ch 2 ("Invest points now") sets `upstream.pendingTarget`, and the autosave stores it. Two cases:

* If the app is killed while that Stats dialog is open, then on Continue the scene shows its choices, but every tap gives "Close Stats before continuing."
* Back after confirming such an allocation (or after closing it with no allocation) restores the same pending state.

The only way forward is to open Stats from the toolbar and close it. Nothing is lost, but the screen tells the player to close a dialog that is not open.

**Where.** `src/engine.js` line 29, `choose()`, which throws. `src/engine.js` line 48: `restore()` keeps `pendingTarget` when the stores are unchanged. `src/model.js` line 28, `invest()`, pushes the pending record. `src/app.js` line 22 (Continue) and line 24 (Back) render without reopening Stats. The close handler is at line 89.

**Reproduction.** `r3-pending-stats.cjs` follows real play from Ch 1 to `Ch2-Stats`, opens Stats, creates a fresh model, and calls `load('-auto')`. `app-level.cjs` repeats this in the real UI.

* Expected: the Stats dialog reopens.
* Actual: no dialog, and every choice shows the toast.

The fuzz test hit the Back variant 82 times.

**Proposed correction.** In `app.js` `render()`, after `sync()`: `if(engine.pendingStats()&&!$('statsDialog').hasAttribute('open'))openStats();`. This is in the trial copy. In jsdom the dialog reopens, and closing it enters `Ch2-Stats-spent`.

**Compatibility.** No data change. Optionally, `back()` could skip a pending record and go straight to the pre-choice state. That would change Back semantics, so I would keep the UI fix only.

---

## Plausible concerns (not defects by themselves, or not verifiable here)

* **C1 — The checkpoint is global, not tied to the loaded save.** Example: a player loads a Book 3 named save, then dies before reaching a new checkpoint. "Load from last checkpoint" sends them to the checkpoint of whatever run last wrote it, possibly Book 1 of another game, and the autosave is overwritten (`c1-cross-run-checkpoint.cjs`). Thuiop behaves the same way, so the differential tests cannot detect it. Whether Cristian's original app did the same should decide this.
  * If not, a light fix is a random `runId` field at the top level of the snapshot. `restore()` keeps unknown top-level fields, so legacy saves would be unaffected. Warn or confirm when the checkpoint's `runId` differs.
  * Storing a checkpoint inside every slot would add about 23 KB per slot. With 30 slots that approaches the 2 MiB backup limit.
* **C2 — One damaged record blocks export and is shown as an empty slot.** `backup.create()` (lines 51 and 54) aborts on any unreadable or invalid record. In the slot list (`app.js` line 31) an unreadable slot reads as "Empty" and can be overwritten without warning, and an unreadable `-auto` disables Continue. Reproduced with injected corruption (`r4-import.cjs`). Real corruption should be rare.
  * Suggestion: export valid records, report the skipped ones, and label unreadable slots as "Damaged" rather than "Empty". Do not overwrite a damaged `-auto` without first copying it aside.
* **C3 — Update path to Google Play (unverified).** The manifest has `android:allowBackup="false"`, so Android will not restore saves after an uninstall or a device change. If Play App Signing re-signs the build with a key other than the original certificate (`680be316…`), anyone with the sideloaded APK must uninstall before installing the Play build, and all saves are lost unless exported.
  * Please compare the "App signing key certificate" SHA-256 in Play Console with `tests/android-signature.txt` before inviting testers who used the APK.
* **C4 — Durability of the last autosave on a process kill (unverified).** `MainActivity.onPause` only calls `WebView.onPause()`; disassembly shows no explicit storage flush. Chromium commits localStorage in batches, so a force-stop or swipe-away immediately after a choice might lose that last step. This needs a device test.
* **C5 — Configuration changes outside `configChanges` (unverified).** These include dark-mode or `uiMode`, font scale, split-screen, folding and `screenLayout`. They would recreate the activity, and `onCreate` always loads the title screen. The player would have to press Continue. No data is lost.
* **C6 — Import storage needs.** The import journal duplicates every save, so import needs about twice the current storage. With less space it is refused cleanly, which I verified. It is still worth knowing on near-full devices.

## Optional improvements

* `npm test` fails 1/21 on a clean unpack, because `release.cjs` test 12 reads `dist/…v0.2.9.html`. Either run `build` from the test script or document the order. The "21 passed" result depends on a prior build.
* Backup headroom: 30 late-game slots take 1.28 MB of the 2 MiB limit (`r-size.cjs`). Each snapshot stores the variables three times (`vars`, `upstream.current/awards`, `upstream.input`), and each slot also embeds two book starts. This is fine today, but any future additions (for example a per-slot checkpoint) would need compaction.
* `-chapter-starts` (up to 34 full snapshots, about 0.7 MB) is written on every chapter intro. It is not used by the public build, other than as the possible B2 recovery source.
* Keep an automatic pre-import copy, for example by retaining the journal as `-pre-import` until the next successful import. Import otherwise replaces all 30 slots and the autosave with no undo.
* The original runtime logs "Condition fail / False" for the literal `False` condition in `B3-Ch05a-Untangle`. This is harmless upstream behaviour (it evaluates as false), but it is noisy in logs.

## What held up (verified)

* **Import transactionality** (`r4-import.cjs`):
  * Under simulated storage limits, from 1.05× to 2.2× of current usage, the import either completed fully or left storage byte-identical.
  * A simulated kill mid-import left the journal behind, and `recover()` restored the exact previous storage.
  * 10-slot backups without book-start records are accepted.
* **Round-trip property test** (`fuzz-roundtrip.cjs`, 3 seeds × 34 chapter starts × up to 120 steps, 8,277 state checks, with random toolbar allocations and checkpoint loads on death):
  * a fresh app instance loading `-auto` always reproduced the same variables and the same rendered scene;
  * Back followed by the same choice never changed the variables, so no rewards were applied twice;
  * export/parse succeeded throughout.
  * The only failures were B4 and a harness artifact at `Ch1-Retreat`, which has no checkpoint button. The random walk did not reach the B1 window.
* After the trial corrections, the existing differential, sequence, stats-reference, achievement-navigation, reset-persistence and backup-rejection checks report 0 mismatches.

## Challenge to the existing coverage

* The **differential tests** excluded impossible-stat inputs, which is how B1 escaped. Agreement with Thuiop also cannot flag C1, because Thuiop shares it. It cannot flag B3 either, because the adapter merged two stores that Thuiop keeps separate, and no test compared the two across a reload.
* The **sequence check** never saves, reloads or Backs mid-run. Its 8 seeds × 150 transitions per chapter do not reach most conditional routes; B2 Ch 10b's secret-code branch is one example.
* **"All 136 achievements reachable"** (achievement-navigation) checks that each card can be reached in the achievements browser. It does not check that each achievement can be earned in play.
* The **backup rejection check** covers parse-time rejection only. The write-boundary and recovery paths had no test before `r4-import.cjs`.
* No test covers app kill → Continue for dialogs or pending states, or checkpoint load's side effects on other records.

## Most useful missing tests

1. A save → reload → Back → export round-trip at every step, including a scripted Book 2 Ch 10b → Ch 11c secret-code run with Hearing 2–4 (B1).
2. A checkpoint load in Books 2 and 3, with the checkpoint after Chapter 1, that asserts the book starts and "Restart Book N" survive (B2).
3. Book 3 Ch 9: six deaths with checkpoint reloads, asserting that Consolation prize is earned once (B3).
4. Kill while a story Stats screen is open → Continue, and Back over a confirmed story allocation (B4).
5. One corrupt or invalid record present: export behaviour and slot-list labelling (C2).
6. On a device: force-stop immediately after a choice; update 0.2.8 → 0.2.9 from Play; sideloaded APK → Play build signature check (C3, C4).
7. Make `npm test` self-contained, building first.
