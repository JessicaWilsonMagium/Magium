# Magium Text 0.2.15 — focused review candidate

Offline Android text edition using Thuiop’s MIT-licensed MagiumJS interpreter.
See CREDITS.md, LICENSE and ATTRIBUTION.txt.
Install as Update without uninstalling to retain progress.
Run `npm ci`, then `npm test` (60 tests).
See PHONE-TEST-AND-REVIEW.md for the export-priority refinement.
No signing credentials or Android SDK are included.
