/* Offline adapter: original selection/storage routines, snapshot-aware reader API.
 * See ADAPTER.md for the deliberate UI, stat-refresh and save-import policies. */
(function(root){
 'use strict';
 const node=typeof module!=='undefined'&&module.exports,O=root.MagiumOriginal||(node?require('./original-runtime'):null);
 const stats=[['strength','Strength'],['toughness','Toughness'],['agility','Speed'],['reflexes','Reflexes'],['hearing','Hearing'],['perception','Observation'],['ancient_languages','Ancient languages'],['combat_technique','Combat technique'],['premonition','Premonition'],['bluff','Bluff'],['magical_sense','Magical sense'],['aura_hardening','Aura hardening']];
 const clone=x=>JSON.parse(JSON.stringify(x)),numeric=v=>typeof v==='string'&&/^-?\d+$/.test(v)?Number(v):v;
 function location(id){const m=/^(?:B(\d+)-)?Ch(\d+)/.exec(id);if(!m)throw Error('Invalid scene location '+id);return {book:Number(m[1]||1),chapter:Number(m[2])};}
 function chapters(data){const groups=new Map();for(const id of Object.keys(data)){const p=location(id);groups.set(p.book+':'+p.chapter,p)}return [...groups.values()].sort((a,b)=>a.book-b.book||a.chapter-b.chapter);}
 function split(vars){const stores={currentState:{},achievements:{}};for(const [k,v]of Object.entries(vars))(k.startsWith('v_ac_')?stores.achievements:stores.currentState)[k]=String(v);return stores;}
 function assign(vars,key,value){const b=O.storageBridge(split(vars));b.storeVariable(key,value);Object.assign(vars,Object.fromEntries(Object.entries({...b.read().currentState,...b.read().achievements}).map(([k,v])=>[k,numeric(v)])));}
 function create(data,initial){
  const renderOriginal=O.renderer(data);let state,bridge,display;
  const statNames=new Set(stats.map(([k])=>'v_'+k).concat('v_available_points'));
  const raw=()=>{const r=bridge.read();return {...r.currentState,...r.achievements}};
  const normalize=()=>Object.fromEntries(Object.entries(raw()).map(([k,v])=>[k,numeric(v)]));
  function sync(){const b=bridge.read();state.vars=normalize();state.upstream.current=b.currentState;state.upstream.awards=b.achievements;}
  function renderInput(input,mode='entry'){
   const id=input.v_current_scene,scene=data[id];if(!scene)throw Error('Missing original scene '+id);
   // Stat confirmation refreshes outcomes but does not re-grant entry rewards.
   const override=mode==='refresh'?{...scene,setVariables:scene.setVariables.filter(x=>x.conditions?.flat().some(c=>statNames.has(c.split(' ')[0]))&&!/^[+-]\d+$/.test(String(x.value)))}:undefined;
   return renderOriginal(input,override).scene;
  }
  function rememberAwards(scene){for(const a of scene.achievements){bridge.storeVariable(a.variable,'2');if(!state.achievements.includes(a.text))state.achievements.push(a.text);}}
  function select(input,mode='entry',apply=false){display=renderInput(input,mode);state.upstream.input=clone(input);state.upstream.mode=mode;if(apply){for(const x of display.setVariables)bridge.storeVariable(x.name,x.value);rememberAwards(display);sync();}}
  function enter(id){if(!data[id])throw Error('Missing original scene '+id);state.id=id;state.page=0;state.finished=false;delete state.readingPosition;delete state.upstream.pendingTarget;bridge.storeVariable('v_current_scene',id);if(/^Ch3-Clobber2?$/.test(id))bridge.storeVariable('v_is_dead','0');select(raw(),'entry',true);}
  function restart(){state={version:1,id:'Ch1-Intro1',page:0,vars:{},achievements:[],finished:false,upstream:{version:1}};const initial={v_available_points:0,v_max_stat:3};for(const[k]of stats)initial['v_'+k]=0;bridge=O.storageBridge(split(initial));enter('Ch1-Intro1');return snapshot();}
  function view(){const complete=state.id==='B3-Ch12b-Credits',choices=clone(display.choices),checks=display.statChecks.map(x=>({stat:stats.find(([,name])=>name===x.variable)?.[0]||x.variable,required:x.value,pass:!!x.success}));const dead=!complete&&(state.id==='Ch1-Retreat'||(choices.length>0&&choices.every(c=>['restart','checkpoint_load','saves'].includes(c.special))));return {id:state.id,paragraphs:clone(display.paragraphs),choices,checks,dead,complete,finished:false};}
  function choose(index){if(state.upstream.pendingTarget)throw Error('Close Stats before continuing.');const c=display.choices[index];if(!c)throw Error('Invalid choice');if(c.special==='restart'){restart();return {special:'restart'}}if(['checkpoint_load','saves'].includes(c.special))return {special:c.special};bridge.setResponseVariables(c);sync();if(c.special==='stats'){state.upstream.pendingTarget=c.target;return {special:'stats'}}enter(c.target);return {special:c.special};}
  function invest(allocation){
   if(state.vars.v_b3_ch3_stats_unavailable===1)throw Error('The stat device is unavailable.');const p=location(state.upstream.pendingTarget||state.id),magic=p.book===3&&p.chapter>=4;let used=0;
   for(const[k,n]of Object.entries(allocation)){if(!stats.some(([s])=>s===k)||(!magic&&stats.slice(9).some(([s])=>s===k))||!Number.isInteger(n)||n<0||Number(state.vars['v_'+k]||0)+n>Number(state.vars.v_max_stat||3))throw Error('Invalid allocation');used+=n;}
   if(used>state.vars.v_available_points)throw Error('Not enough points');
   // Original confirmStats writes integer values, rather than storeVariable strings.
   const values={v_available_points:state.vars.v_available_points-used};for(const[k]of stats)values['v_'+k]=Number(state.vars['v_'+k]||0)+(allocation[k]||0);bridge.confirmAllocation(values);sync();
   if(state.upstream.pendingTarget)enter(state.upstream.pendingTarget);else select(raw(),'refresh',true);
   return snapshot();
  }
  function snapshot(){sync();return clone(state);}
  function restore(saved){
   if(!saved||saved.version!==1||!data[saved.id]||!Number.isInteger(saved.page)||saved.page<0||!saved.vars||!Array.isArray(saved.achievements))throw Error('Invalid save');
   const next=clone(saved),v=next.vars;for(const[k]of stats.slice(9))if(v['v_'+k]===undefined)v['v_'+k]=0;const cap=Number(v.v_max_stat||3);if(![3,4].includes(cap))throw Error('Invalid saved stat cap');for(const[k]of stats){const n=v['v_'+k];if(!Number.isInteger(n)||n<0||n>(k==='hearing'?cap+3:cap))throw Error('Invalid saved stat');}if(!Number.isInteger(v.v_available_points)||v.v_available_points<0)throw Error('Invalid saved points');
   const repaired=/^Ch3-Clobber2?$/.test(next.id)&&Number(v.v_is_dead)!==0;if(repaired)v.v_is_dead=0;
   const u=next.upstream,has=u?.version===1&&u.current&&u.awards&&u.input&&data[u.input.v_current_scene];
   const b=O.storageBridge(has?{currentState:u.current,achievements:u.awards}:split(v));let changed=repaired;
   if(has){const r=b.read(),all={...r.currentState,...r.achievements};for(const[k,value]of Object.entries(v))if(numeric(all[k])!==value){(k.startsWith('v_ac_')?r.achievements:r.currentState)[k]=String(value);changed=true;}for(const k of Object.keys(all))if(!Object.hasOwn(v,k)){delete r.currentState[k];delete r.achievements[k];changed=true;}b.replace(r);}
   const input=has&&!changed?clone(u.input):{...b.read().currentState,...b.read().achievements,v_current_scene:next.id},mode=has&&!changed?u.mode||'entry':'refresh';
   const computed=renderInput(input,mode);state=next;state.upstream=has?clone(u):{version:1,migratedFrom:'text-edition-v1'};if(changed)delete state.upstream.pendingTarget;bridge=b;display=computed;state.upstream.input=input;state.upstream.mode=mode;state.finished=false;sync();return snapshot();
  }
  function restartBookTwo(saved){if(!saved?.id?.startsWith('B2-'))throw Error('Book 2 has not been reached.');restore(saved);const b=bridge.read();for(const k of Object.keys(b.currentState))if(k.startsWith('v_b2_'))delete b.currentState[k];for(const k of Object.keys(b.achievements))if(k.startsWith('v_ac_b2_')&&b.achievements[k]!=2)delete b.achievements[k];bridge.replace(b);bridge.storeVariable('v_is_dead','0');bridge.storeVariable('v_checkpoint_rich','1');bridge.storeVariable('v_chapter_save_counter','5');enter('B2-Ch01a-Intro');return snapshot();}
  function page(n){if(!Number.isInteger(n)||n<0)throw Error('Invalid page');state.page=n;}
  if(initial){state={version:1,id:initial.id,page:0,vars:{},achievements:[],finished:false,upstream:{version:1}};bridge=O.storageBridge(initial.stores);enter(initial.id);}else restart();
  return {restart,restartBookTwo,view,choose,invest,snapshot,restore,page,pendingStats:()=>!!state.upstream.pendingTarget,statsOpened:()=>{bridge.initializeStats();sync();}};
 }
 const api={create,stats,conditions:O.conditions,assign,location,chapters};if(node)module.exports=api;else root.MagiumEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this);
