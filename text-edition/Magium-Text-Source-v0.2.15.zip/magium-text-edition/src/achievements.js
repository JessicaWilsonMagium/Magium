/* Cristian's original awards; the collection is separate from branching save state. */
(function(root){
 'use strict';
 const originalBookOne={"b1ch1": [{"title": "Who are you calling a coward?", "caption": "A true warrior never backs down from a challenge.", "chapter": "b1ch1", "variable": "v_ac_ch1_coward"}, {"title": "Off to a good start", "caption": "Died before reaching the first checkpoint.", "chapter": "b1ch1", "variable": "v_ac_ch1_die"}, {"title": "Honesty is the best policy.", "caption": "A clean mouth and an honest hand will take a man through any land.", "chapter": "b1ch1", "variable": "v_ac_ch1_honesty"}], "b1ch2": [{"title": "Smooth talker", "caption": "Choosing the right words at the right time can be a daunting task for many, but you make it look so easy.", "chapter": "b1ch2", "variable": "v_ac_ch2_talker"}, {"title": "Tough as nails", "caption": "Got stabbed in the neck with a dagger and lived to tell the tale.", "chapter": "b1ch2", "variable": "v_ac_ch2_nails"}, {"title": "Martial arts master", "caption": "Successfully disarmed an opponent while fighting barehanded.", "chapter": "b1ch2", "variable": "v_ac_ch2_master"}, {"title": "An unlikely ally", "caption": "Sometimes, friends can come from the most unexpected places.", "chapter": "b1ch2", "variable": "v_ac_ch2_unlikely"}], "b1ch3": [{"title": "A message in the sky", "caption": "It's a beautiful night for stargazing, don't you think?", "chapter": "b1ch3", "variable": "v_ac_ch3_message"}, {"title": "One man army", "caption": "Singlehandedly defeated a small army of one hundred armed men, as well as their leader.", "chapter": "b1ch3", "variable": "v_ac_ch3_army"}, {"title": "That was close!", "caption": "Saved a friend in the nick of time from an incoming dart.", "chapter": "b1ch3", "variable": "v_ac_ch3_close"}], "b1ch4": [{"title": "A noble sacrifice", "caption": "Gave your own life to save a friend's.", "chapter": "b1ch4", "variable": "v_ac_ch4_noble"}, {"title": "Defeated Cutthroat Dave", "caption": "Won a duel against Cutthroat Dave.", "chapter": "b1ch4", "variable": "v_ac_ch4_cutthroat"}, {"title": "I really kneed a break!", "caption": "Break both of your knees from a fall.", "chapter": "b1ch4", "variable": "v_ac_ch4_kneed"}], "b1ch5": [{"title": "Stat device wielder", "caption": "Upon lending the stat device to Daren, you make an unexpected discovery.", "chapter": "b1ch5", "variable": "v_ac_ch5_wielder"}, {"title": "Admitted liar", "caption": "Sometimes you just have to grab the bull by the horns.", "chapter": "b1ch5", "variable": "v_ac_ch5_liar"}, {"title": "A good deed", "caption": "Even a small act of selflessness can go a long way.", "chapter": "b1ch5", "variable": "v_ac_ch5_deed"}, {"title": "Shameless", "caption": "Take the credit for someone else's deeds, without any shame.", "chapter": "b1ch5", "variable": "v_ac_ch5_shameless"}], "b1ch6": [{"title": "Defeated Tyrath", "caption": "Won a duel against Tyrath, the king of all dragons.", "chapter": "b1ch6", "variable": "v_ac_ch6_tyrath"}, {"title": "Berserker mode activated", "caption": "Accidentally maximized all of your stats in a fit of rage.", "chapter": "b1ch6", "variable": "v_ac_ch6_berserker"}, {"title": "Full immersion", "caption": "Experience what your in-game character sees, first hand.", "chapter": "b1ch6", "variable": "v_ac_ch6_immersion"}], "b1ch7": [{"title": "Violence is not the answer", "caption": "Why bother to fight, if you can just bluff your way to victory?", "chapter": "b1ch7", "variable": "v_ac_ch7_answer"}, {"title": "Golem crusher", "caption": "Destroy at least one rock golem by yourself in a fight.", "chapter": "b1ch7", "variable": "v_ac_ch7_crusher"}, {"title": "Defeated Hadrik", "caption": "Won a duel against Hadrik.", "chapter": "b1ch7", "variable": "v_ac_ch7_hadrik"}], "b1ch8": [{"title": "Vive la democratie!", "caption": "Win a democratic vote by a small margin.", "chapter": "b1ch8", "variable": "v_ac_ch8_democratie"}, {"title": "First piece of the puzzle", "caption": "Find the first piece of the puzzle made by Varathia's greatest architect.", "chapter": "b1ch8", "variable": "v_ac_ch8_first"}, {"title": "Hydra slayer", "caption": "Kill a hydra with your own hands.", "chapter": "b1ch8", "variable": "v_ac_ch8_hydra"}], "b1ch9": [{"title": "Keen observer", "caption": "When inside enemy territory, you should always mind your surroundings.", "chapter": "b1ch9", "variable": "v_ac_ch9_observer"}, {"title": "A wise decision", "caption": "Throwing away your pride is never easy, but sometimes there is no other way.", "chapter": "b1ch9", "variable": "v_ac_ch9_decision"}], "b1ch10": [{"title": "Defeated ogre shaman", "caption": "Won a duel against the shaman from the ogre stronghold.", "chapter": "b1ch10", "variable": "v_ac_ch10_shaman"}, {"title": "A toast!", "caption": "Shared a drink with Hadrik to celebrate your most recent victory.", "chapter": "b1ch10", "variable": "v_ac_ch10_toast"}, {"title": "A touching reunion", "caption": "Helped Rose make up with an old friend.", "chapter": "b1ch10", "variable": "v_ac_ch10_reunion"}], "b1ch11": [{"title": "A mysterious symbol", "caption": "Discover a strange marking engraved on the side of a harmless toy.", "chapter": "b1ch11", "variable": "v_ac_ch11_symbol"}, {"title": "Stillwater slayer", "caption": "Defeated five stillwaters all by yourself.", "chapter": "b1ch11", "variable": "v_ac_ch11_stillwater"}, {"title": "No casualties", "caption": "No members of your group died in the first book.", "chapter": "b1ch11", "variable": "v_ac_ch11_casualties"}, {"title": "Average Joe", "caption": "Finished the first book without leveling up a single stat.", "chapter": "b1ch11", "variable": "v_ac_ch11_average"}]};
 const originalBookTwo={"b2ch1": [{"title": "Bearer of bad news", "caption": "Volunteer to take the role that nobody else wants to take.", "chapter": "b2ch1", "variable": "v_ac_b2_ch1_news"}, {"title": "Long-distance", "caption": "Find out the reason why Daren decided to create his enchanted transceivers.", "chapter": "b2ch1", "variable": "v_ac_b2_ch1_distance"}, {"title": "Second piece of the puzzle", "caption": "Find the second piece of the puzzle made by Varathia's greatest architect.", "chapter": "b2ch1", "variable": "v_ac_b2_ch1_second"}, {"title": "Half-breed", "caption": "Find out an interesting detail about your lineage.", "chapter": "b2ch1", "variable": "v_ac_b2_ch1_breed"}], "b2ch2": [{"title": "Come at me, bro!", "caption": "Take all of your opponent's hits head-on, instead of trying to defend yourself.", "chapter": "b2ch2", "variable": "v_ac_b2_ch2_bro"}, {"title": "The easy way out", "caption": "Accept the help of a shady individual, without lying to him, in exchange for making your life easier in the arena.", "chapter": "b2ch2", "variable": "v_ac_b2_ch2_easy"}, {"title": "Fourth wall breaker", "caption": "Make a reference that your game character would have no way of knowing without breaking the fourth wall.", "chapter": "b2ch2", "variable": "v_ac_b2_ch2_wall"}, {"title": "Griffin rider", "caption": "Ride a griffin and live to tell the tale.", "chapter": "b2ch2", "variable": "v_ac_b2_ch2_griffin"}], "b2ch3": [{"title": "Once an enemy, now an ally", "caption": "Convince an enemy troll to join your side.", "chapter": "b2ch3", "variable": "v_ac_b2_ch3_enemy"}, {"title": "The golden cage", "caption": "Find out why Illuna can cast the spirit fox's golden cage.", "chapter": "b2ch3", "variable": "v_ac_b2_ch3_cage"}], "b2ch41": [{"title": "Not a team player", "caption": "Get two of the members from your division killed, through your actions.", "chapter": "b2ch41", "variable": "v_ac_b2_ch4_player"}, {"title": "Intimidation successful", "caption": "Manage to avoid an assassination attempt by intimidating your adversary into not attacking you.", "chapter": "b2ch41", "variable": "v_ac_b2_ch4_intimidation"}, {"title": "Hadrik saves the day!", "caption": "Witness Hadrik's second fight in the arena.", "chapter": "b2ch41", "variable": "v_ac_b2_ch4_hadrik"}, {"title": "A calculated risk", "caption": "Sometimes it's better to take small risks than to go the extra mile just to be completely certain.", "chapter": "b2ch41", "variable": "v_ac_b2_ch4_risk"}, {"title": "Trampler slayer", "caption": "Defeat two tramplers by yourself.", "chapter": "b2ch41", "variable": "v_ac_b2_ch4_trampler"}], "b2ch42": [{"title": "Spear thrower", "caption": "Kill a manticore in mid-flight, by throwing a spear at it.", "chapter": "b2ch42", "variable": "v_ac_b2_ch4_spear"}, {"title": "Who needs stats?", "caption": "Win the first round of the arena without any points in your stats, and without help from the scythe wielding lessathi.", "chapter": "b2ch42", "variable": "v_ac_b2_ch4_stats"}, {"title": "Time stop", "caption": "Witness Rose subconsciously casting a time freezing spell, for the first time.", "chapter": "b2ch42", "variable": "v_ac_b2_ch4_time"}, {"title": "The assassin's motive", "caption": "Find out the assassin's reason for wanting to kill you in the arena.", "chapter": "b2ch42", "variable": "v_ac_b2_ch4_motive"}], "b2ch5": [{"title": "Tribal dancer", "caption": "Perform a tribal dance while dodging pillars of fire.", "chapter": "b2ch5", "variable": "v_ac_b2_ch5_tribal"}, {"title": "Divide and conquer", "caption": "Win against the troll by turning his own allies against him.", "chapter": "b2ch5", "variable": "v_ac_b2_ch5_divide"}, {"title": "Public speaker", "caption": "Hold a speech in front of the arena crowds, after one of your victories.", "chapter": "b2ch5", "variable": "v_ac_b2_ch5_speaker"}, {"title": "United we stand", "caption": "Get Wilhelm and the gladiator that you fight against in the third round to join your team in the bonus round.", "chapter": "b2ch5", "variable": "v_ac_b2_ch5_united"}], "b2ch6": [{"title": "Secret code discovered", "caption": "Learn about a secret code that gives you a temporary bonus to your Hearing stat.", "chapter": "b2ch6", "variable": "v_ac_b2_ch6_secret"}, {"title": "Living on the edge", "caption": "Expend most of your budget with a single purchase.", "chapter": "b2ch6", "variable": "v_ac_b2_ch6_edge"}], "b2ch7": [{"title": "Just an average assassin", "caption": "Complete king Golmyck's mission without having any points invested in your stats.", "chapter": "b2ch7", "variable": "v_ac_b2_ch7_average"}, {"title": "Found the culprit", "caption": "Find out who sabotaged Golmyck's telepathic message device.", "chapter": "b2ch7", "variable": "v_ac_b2_ch7_culprit"}, {"title": "Message delivered", "caption": "Deliver Eiden's still winter message to its rightful recipients.", "chapter": "b2ch7", "variable": "v_ac_b2_ch7_delivered"}, {"title": "Message delivered", "caption": "Survive the powerful grip of a giant stone hand, without getting crushed.", "chapter": "b2ch7", "variable": "v_ac_b2_ch7_cookie"}], "b2ch8": [{"title": "Stillwater trivia", "caption": "Find out important information about the stillwaters, and their origins.", "chapter": "b2ch8", "variable": "v_ac_b2_ch8_trivia"}, {"title": "Unexpected savior", "caption": "When you are in a pinch, help does not always come from where you'd expect.", "chapter": "b2ch8", "variable": "v_ac_b2_ch8_savior"}, {"title": "Tree wielder", "caption": "Who needs weapons, when you can just use trees as clubs?", "chapter": "b2ch8", "variable": "v_ac_b2_ch8_tree"}, {"title": "Side effects", "caption": "Experience first-hand the side effects of your protection spell.", "chapter": "b2ch8", "variable": "v_ac_b2_ch8_effects"}, {"title": "A true gentleman", "caption": "Offer to take an extra night shift, in order to make sure that your lady guest gets a good night's sleep.", "chapter": "b2ch8", "variable": "v_ac_b2_ch8_gentleman"}], "b2ch9": [{"title": "Something is missing", "caption": "Does this backpack feel lighter to anyone else, or is it just me?", "chapter": "b2ch9", "variable": "v_ac_b2_ch9_missing"}, {"title": "I'm a helper!", "caption": "Help the animals in the forest to complete their mission.", "chapter": "b2ch9", "variable": "v_ac_b2_ch9_helper"}, {"title": "Long live the king!", "caption": "Learn a shocking truth about the current state of affairs in Thilias.", "chapter": "b2ch9", "variable": "v_ac_b2_ch9_king"}, {"title": "Master of cards", "caption": "Win a card game against Hadrik.", "chapter": "b2ch9", "variable": "v_ac_b2_ch9_cards"}], "b2ch10": [{"title": "A creative solution", "caption": "Not all battles need to be won through fighting.", "chapter": "b2ch10", "variable": "v_ac_b2_ch10_creative"}, {"title": "Mammoth slayer", "caption": "Kill a mammoth with your own hands.", "chapter": "b2ch10", "variable": "v_ac_b2_ch10_mammoth"}, {"title": "Demolition man", "caption": "You seem to really enjoy smashing big rocks into one another. Ever thought about doing this for a living?", "chapter": "b2ch10", "variable": "v_ac_b2_ch10_demolition"}, {"title": "Stalker detected", "caption": "Do you ever get the feeling that you are being watched?", "chapter": "b2ch10", "variable": "v_ac_b2_ch10_stalker"}], "b2ch11": [{"title": "Supportive friend", "caption": "Encourage a friend who just had an epiphany and wants to change their life for the better. ", "chapter": "b2ch11", "variable": "v_ac_b2_ch11_supportive"}, {"title": "Madman", "caption": "Attack Arraka with a dagger for the second time, and live to tell the tale.", "chapter": "b2ch11", "variable": "v_ac_b2_ch11_madman"}, {"title": "Cutthroat vs god", "caption": "Witness an epic confrontation between a cutthroat and a god.", "chapter": "b2ch11", "variable": "v_ac_b2_ch11_cutthroat"}, {"title": "Average Joe 2", "caption": "Finished the first two books without leveling up a single stat.", "chapter": "b2ch11", "variable": "v_ac_b2_ch11_average2"}, {"title": "A hidden truth", "caption": "Find out what happened to Barry's biological parents.", "chapter": "b2ch11", "variable": "v_ac_b2_ch11_hidden"}, {"title": "The elephant in the room", "caption": "There's always that one guy who can't take a hint and who doesn't realize that some things are better left unsaid.", "chapter": "b2ch11", "variable": "v_ac_b2_ch11_elephant"}]};
 const originalBookThree={
    "b3ch1": [
        {
            "title": "No regrets",
            "caption": "He who risks nothing can gain nothing.",
            "chapter": "b3ch1",
            "variable": "v_ac_b3_ch1_regrets"
        },
        {
            "title": "Password acquired",
            "caption": "You never know when a secret code might come in handy.",
            "chapter": "b3ch1",
            "variable": "v_ac_b3_ch1_password"
        }
    ],
    "b3ch2": [
        {
            "title": "Metal golem slayer",
            "caption": "Kill a large metal golem with your own hands.",
            "chapter": "b3ch2",
            "variable": "v_ac_b3_ch2_metal"
        },
        {
            "title": "Time to get serious",
            "caption": "Sometimes, you just need to pull out all the stops.",
            "chapter": "b3ch2",
            "variable": "v_ac_b3_ch2_serious"
        },
        {
            "title": "I cannot tell a lie.",
            "caption": "Honest Barry is what they call you.",
            "chapter": "b3ch2",
            "variable": "v_ac_b3_ch2_lie"
        },
        {
            "title": "Reckless",
            "caption": "Live up to your new nickname.",
            "chapter": "b3ch2",
            "variable": "v_ac_b3_ch2_reckless"
        }
    ],
    "b3ch3": [
        {
            "title": "Ominous foreshadowing",
            "caption": "Were you perhaps expecting something less vague?",
            "chapter": "b3ch3",
            "variable": "v_ac_b3_ch3_ominous"
        },
        {
            "title": "An unexpected bonus",
            "caption": "Not all mistakes lead to misfortune.",
            "chapter": "b3ch3",
            "variable": "v_ac_b3_ch3_unexpected"
        },
        {
            "title": "A job well done!",
            "caption": "Congratulations! You managed to find the only death scene in this chapter. (You were doing it on purpose, right?) ",
            "chapter": "b3ch3",
            "variable": "v_ac_b3_ch3_job"
        },
        {
            "title": "An unforeseen premonition",
            "caption": "Hint: Your stat device will not help you here.",
            "chapter": "b3ch3",
            "variable": "v_ac_b3_ch3_unforeseen"
        }
    ],
    "b3ch4": [
        {
            "title": "Fourth wall demolisher",
            "caption": "Did you ever break the 4th wall so hard that you felt you could almost see through the cracks?",
            "chapter": "b3ch4",
            "variable": "v_ac_b3_ch4_demolisher"
        },
        {
            "title": "A hidden alliance",
            "caption": "Form a secret alliance with a potential new king of Ollendor.",
            "chapter": "b3ch4",
            "variable": "v_ac_b3_ch4_alliance"
        },
        {
            "title": "A master of deception",
            "caption": "Your quick wit and improvisation skills are second to none. Nobody is better at lying than you.",
            "chapter": "b3ch4",
            "variable": "v_ac_b3_ch4_deception"
        },
        {
            "title": "Rock throwing champion",
            "caption": "Defeat a very powerful adversary using only a rock taken from the ground.",
            "chapter": "b3ch4",
            "variable": "v_ac_b3_ch4_thrower"
        }
    ],
    "b3ch5": [
        {
            "title": "Opportunist",
            "caption": "Why give away anything for free when you can make a small profit instead?",
            "chapter": "b3ch5",
            "variable": "v_ac_b3_ch5_opportunist"
        },
        {
            "title": "The good old days",
            "caption": "Reenact one of the night shifts from the first days of the tournament.",
            "chapter": "b3ch5",
            "variable": "v_ac_b3_ch5_days"
        },
        {
            "title": "I can hear footsteps.",
            "caption": "Listen carefully. The assassin is getting nearer.",
            "chapter": "b3ch5",
            "variable": "v_ac_b3_ch5_footsteps"
        },
        {
            "title": "Challenge accepted",
            "caption": "Take on a challenge that not many mortals would dare to attempt.",
            "chapter": "b3ch5",
            "variable": "v_ac_b3_ch5_passed"
        }
    ],
    "b3ch61": [
        {
            "title": "A natural liar",
            "caption": "Lie so well that you make someone question their own short-term memory.",
            "chapter": "b3ch61",
            "variable": "v_ac_b3_ch6_natural"
        },
        {
            "title": "Nice assist",
            "caption": "Get help from someone that you've fought against in the past.",
            "chapter": "b3ch61",
            "variable": "v_ac_b3_ch6_assist"
        },
        {
            "title": "Peek-a-boo!",
            "caption": "Win a very complex game of hide and seek.",
            "chapter": "b3ch61",
            "variable": "v_ac_b3_ch6_peek"
        },
        {
            "title": "An assassin's credo",
            "caption": "Find out what it means to be a true assassin from a skilled practitioner of the craft.",
            "chapter": "b3ch61",
            "variable": "v_ac_b3_ch6_credo"
        },
        {
            "title": "Guardian angel",
            "caption": "Prevent someone from dying after seeing their death in a vision.",
            "chapter": "b3ch61",
            "variable": "v_ac_b3_ch6_guardian"
        }
    ],
    "b3ch62": [
        {
            "title": "Time freeze enthusiast",
            "caption": "Experience the world being frozen around you two times in the same day.",
            "chapter": "b3ch62",
            "variable": "v_ac_b3_ch6_freeze"
        },
        {
            "title": "Curiosity killed the cat",
            "caption": "Be honest. Did you really fall for the trap, or were you just aiming to get this achievement?",
            "chapter": "b3ch62",
            "variable": "v_ac_b3_ch6_curiosity"
        },
        {
            "title": "Average is my middle name",
            "caption": "Survive the trip to the surface without having any points invested in your stats.",
            "chapter": "b3ch62",
            "variable": "v_ac_b3_ch6_average"
        },
        {
            "title": "Quarantine ender",
            "caption": "Help Daren save everyone from the quarantine area in the underground tunnels below Ollendor.",
            "chapter": "b3ch62",
            "variable": "v_ac_b3_ch6_quarantine"
        },
        {
            "title": "Do you hear an echo?",
            "caption": "Listen to a conversation that is happening at the opposite end of a long underground tunnel.",
            "chapter": "b3ch62",
            "variable": "v_ac_b3_ch6_echoes"
        }
    ],
    "b3ch7": [
        {
            "title": "An honorable victory",
            "caption": "Defeat Gontrok without taking advantage of his bet with Leila.",
            "chapter": "b3ch7",
            "variable": "v_ac_b3_ch7_honorable"
        },
        {
            "title": "Sharpshooter",
            "caption": "An achievement awarded only to those with unmatched crossbow skills.",
            "chapter": "b3ch7",
            "variable": "v_ac_b3_ch7_sharpshooter"
        },
        {
            "title": "Paranoid",
            "caption": "The whole world is out to get you. You can't trust anyone. Not even yourself.",
            "chapter": "b3ch7",
            "variable": "v_ac_b3_ch7_paranoid"
        }
    ],
    "b3ch8": [
        {
            "title": "Master of bluffing",
            "caption": "Successfully bluff a living lie detector.",
            "chapter": "b3ch8",
            "variable": "v_ac_b3_ch8_bluffer"
        },
        {
            "title": "An unusual candidate",
            "caption": "Convince Kelrim to become a candidate for the throne of Ollendor.",
            "chapter": "b3ch8",
            "variable": "v_ac_b3_ch8_unusual"
        },
        {
            "title": "A heartfelt promise",
            "caption": "Make a promise with Leila that you will go on adventures together after the end of the tournament.",
            "chapter": "b3ch8",
            "variable": "v_ac_b3_ch8_heartfelt"
        },
        {
            "title": "A friend in need",
            "caption": "Help cheer up a friend when he is feeling down.",
            "chapter": "b3ch8",
            "variable": "v_ac_b3_ch8_friend"
        }
    ],
    "b3ch9": [
        {
            "title": "Consolation prize",
            "caption": "A prize awarded for dying more than five times in the same chapter.",
            "chapter": "b3ch9",
            "variable": "v_ac_b3_ch9_prize"
        },
        {
            "title": "An introspective moment",
            "caption": "Take a moment to self-reflect and think about everything that you've achieved.",
            "chapter": "b3ch9",
            "variable": "v_ac_b3_ch9_moment"
        },
        {
            "title": "High-value targets",
            "caption": "Defeat Albert, Peter and the king of the underground without asking the Overseer for help.",
            "chapter": "b3ch9",
            "variable": "v_ac_b3_ch9_targets"
        },
        {
            "title": "No need for trinkets",
            "caption": "Defeat the Overseer without making any use of your stat device.",
            "chapter": "b3ch9",
            "variable": "v_ac_b3_ch9_trinkets"
        }
    ],
    "b3ch10": [
        {
            "title": "Friends with benefits",
            "caption": "Agree to enter a relationship with no strings attached with Melindra after the tournament.",
            "chapter": "b3ch10",
            "variable": "v_ac_b3_ch10_benefits"
        },
        {
            "title": "Third piece of the puzzle",
            "caption": "Find the third piece of the puzzle made by Varathia's greatest architect.",
            "chapter": "b3ch10",
            "variable": "v_ac_b3_ch10_third"
        },
        {
            "title": "No man left behind",
            "caption": "Receive confirmation that every prisoner in the seredium towers has been rescued, including Alice's father.",
            "chapter": "b3ch10",
            "variable": "v_ac_b3_ch10_behind"
        },
        {
            "title": "Let's be reasonable!",
            "caption": "Defuse a hostage situation by remaining calm and collected.",
            "chapter": "b3ch10",
            "variable": "v_ac_b3_ch10_reasonable"
        },
        {
            "title": "Forbidden knowledge",
            "caption": "Find out the true nature of the Magium.",
            "chapter": "b3ch10",
            "variable": "v_ac_b3_ch10_forbidden"
        }
    ],
    "b3ch11": [
        {
            "title": "Fourth piece of the puzzle",
            "caption": "Find the fourth piece of the puzzle made by Varathia's greatest architect.",
            "chapter": "b3ch11",
            "variable": "v_ac_b3_ch11_fourth"
        },
        {
            "title": "A small taste of the big prize",
            "caption": "Use knowledge from the Magium to improve a spell.",
            "chapter": "b3ch11",
            "variable": "v_ac_b3_ch11_taste"
        },
        {
            "title": "Hidden alliance aftermath",
            "caption": "Receive direct confirmation from the Overseer that his plan to free the mage slaves is going smoothly.",
            "chapter": "b3ch11",
            "variable": "v_ac_b3_ch11_aftermath"
        }
    ],
    "b3ch12": [
        {
            "title": "Preparing for the big battle",
            "caption": "Start working on the most important spell to be used against the God of Time.",
            "chapter": "b3ch12",
            "variable": "v_ac_b3_ch12_battle"
        },
        {
            "title": "Tree-hugger",
            "caption": "Become one with nature.",
            "chapter": "b3ch12",
            "variable": "v_ac_b3_ch12_hugger"
        },
        {
            "title": "Serial liar",
            "caption": "Successfully bluff two people in the same chapter and manage to survive.",
            "chapter": "b3ch12",
            "variable": "v_ac_b3_ch12_liar"
        },
        {
            "title": "One Dagger Man",
            "caption": "Survive against a powerful foe, armed with only one dagger.",
            "chapter": "b3ch12",
            "variable": "v_ac_b3_ch12_dagger"
        },
        {
            "title": "Delegator",
            "caption": "Why fight for yourself when you can just have somebody else do it for you?",
            "chapter": "b3ch12",
            "variable": "v_ac_b3_ch12_delegator"
        },
        {
            "title": "(more than) Average Joe",
            "caption": "Reach the end of the third book without leveling up any stats except your magical stats.",
            "chapter": "b3ch12",
            "variable": "v_ac_b3_ch12_average"
        }
    ]
};
 function catalogue(scenes){
  const awards=new Map(),available=new Set(Object.keys(scenes).map(id=>{const m=/^(?:B(\d+)-)?Ch(\d+)/.exec(id);return (m[1]||1)+':'+Number(m[2])}));
  for(const scene of Object.values(scenes))for(const a of scene.achievements){const old=awards.get(a.variable);if(old&&old!==a.text)throw Error('Conflicting achievement '+a.variable);awards.set(a.variable,a.text)}
  const ordered=[];
  for(const [book,metadata]of [[1,originalBookOne],[2,originalBookTwo],[3,originalBookThree]])for(const group of Object.values(metadata))for(const a of group){const chapter=Number(a.chapter.match(/ch(\d+)/)[1]);const actualChapter=book===2&&[41,42].includes(chapter)?4:book===3&&[61,62].includes(chapter)?6:chapter;if(!available.has(book+':'+actualChapter))continue;const parsed=awards.get(a.variable);if(parsed&&parsed!==a.title&&a.variable!=='v_ac_b2_ch7_cookie')throw Error('Achievement title mismatch '+a.variable);if(parsed||['v_ac_ch6_immersion','v_ac_b3_ch9_prize'].includes(a.variable)){ordered.push({id:a.variable,title:parsed||a.title,description:a.caption,book,chapter:actualChapter});awards.delete(a.variable)}}
  if(awards.size)throw Error('Original achievement metadata missing: '+[...awards.keys()]);return ordered;
 }
 const bookOneCatalog=Object.values(originalBookOne).flat().map(a=>({id:a.variable,title:a.title,description:a.caption,chapter:Number(a.chapter.match(/ch(\d+)/)[1])}));
 function create(scenes,storage,key){
  const catalog=catalogue(scenes),known=new Set(catalog.map(a=>a.id));let earned=new Set(),retained=new Set(),persistent=true,consolationDeaths=0;
  function read(){try{const saved=JSON.parse(storage.getItem(key));if(Number.isSafeInteger(saved?.consolationDeaths)&&saved.consolationDeaths>=0)consolationDeaths=Math.max(consolationDeaths,saved.consolationDeaths);if(saved?.version===1&&Array.isArray(saved.earned))for(const id of saved.earned)if(known.has(id))earned.add(id);else if(typeof id==='string'&&/^v_ac_[a-zA-Z0-9_]+$/.test(id))retained.add(id)}catch{persistent=false}}
  function write(){try{storage.setItem(key,JSON.stringify({version:1,earned:[...earned,...retained],consolationDeaths}));persistent=true}catch{persistent=false}}
  function sync(saved){read();const state=saved?.state||saved,added=[],previousDeaths=consolationDeaths;const deaths=state?.vars?.v_ac_b3_ch9_consolation;if(Number.isSafeInteger(deaths)&&deaths>=0)consolationDeaths=Math.max(consolationDeaths,deaths);
   if(state&&Array.isArray(state.achievements)&&state.vars){
    for(const award of catalog)if(!earned.has(award.id)&&(state.achievements.includes(award.title)||state.vars[award.id]===2||(award.id==='v_ac_ch6_immersion'&&state.vars[award.id]===1))){earned.add(award.id);added.push(award)}
   }
   if(added.length||consolationDeaths!==previousDeaths)write();return added;
  }
  function openStats(state){if(state?.id!=='Ch6-Eiden-vs-dragon'||Number(state.vars?.v_maximized_stats_used)!==1)return [];return sync({vars:{v_ac_ch6_immersion:2},achievements:[]})}
  function snapshot(){read();return {version:1,earned:[...new Set([...earned,...retained])],consolationDeaths};}
  function bookTwoAccess(){const all=new Set(snapshot().earned),count=bookOneCatalog.filter(a=>all.has(a.id)).length;return {earned:count,total:35,required:25,remaining:Math.max(0,25-count),unlocked:count>=25};}
  read();return {catalog,sync,openStats,snapshot,bookTwoAccess,has:id=>earned.has(id),count:()=>earned.size,isPersistent:()=>persistent};
 }
 const api={catalogue,create,bookOneCatalog};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MagiumAchievements=api;
})(typeof window!=='undefined'?window:globalThis);

