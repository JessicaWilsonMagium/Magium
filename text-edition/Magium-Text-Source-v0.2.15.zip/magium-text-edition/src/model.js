/* Shared player actions; artwork, audio and DOM are deliberately absent. */
(function(root){
 const node=typeof module!=='undefined'&&module.exports;
 const E=root.MagiumEngine||(node?require('./engine'):null),A=root.MagiumAchievements||(node?require('./achievements'):null),R=root.MagiumRewind||(node?require('./rewind'):null),Access=root.MagiumTextAccess||(node?require('./access'):null);
 const Care=root.MagiumSaveCare||(node?require('./save-care'):null);
 const BASE='magium-text-edition-v1',clone=x=>JSON.parse(JSON.stringify(x));
 const prose=view=>view.paragraphs.map(p=>p.text.replaceAll('<br/>','\n').trim()).filter(Boolean).join('\n\n');
 function paginate(text,budget=1450){if(!text)return [''];const pages=[];for(let at=0;at<text.length;){let end=Math.min(at+budget,text.length);if(end<text.length){let split=text.lastIndexOf('\n\n',end);if(split<at+budget*.5)split=text.lastIndexOf(' ',end);if(split>at)end=split+1;}pages.push(text.slice(at,end));at=end;}return pages;}
 function create(data,storage,config={}){
  const test=false,key=BASE,engine=E.create(data),rewind=R.create();let started=false,pages=[''],pendingAwards=[],checkpointId=null;const intros=new Map();for(const id of Object.keys(data))if(/-Intro(?:1)?$/.test(id)){const p=E.location(id),k=p.book+':'+p.chapter;if(!intros.has(k))intros.set(k,id);}
  const checker=E.create(data),care=Care.create(storage,s=>checker.restore(s));
  const read=s=>{try{return JSON.parse(storage.getItem(key+s))}catch{return null}},write=(s,v)=>{if(/^-(auto|checkpoint|previous-checkpoint|manual|book[23]-start|slot-\d+)$/.test(s))care.protect(s);storage.setItem(key+s,JSON.stringify(v));};
  let collection=A.create(data,{getItem:k=>storage.getItem(k),setItem:(k,v)=>{care.protect('-achievements');storage.setItem(k,v)}},key+'-achievements');for(const s of ['-auto','-checkpoint','-manual','-book2-start','-book3-start',...Array.from({length:30},(_,i)=>'-slot-'+(i+1))])collection.sync(read(s));
  function snapshot(){const s=engine.snapshot();if(checkpointId)s.checkpointId=checkpointId;else delete s.checkpointId;s.readingPosition={id:s.id,offset:pages.slice(0,s.page).reduce((n,p)=>n+p.length,0)};return s;}
  function refresh(offset){const s=engine.snapshot(),view=engine.view();pages=paginate(prose(view));let p=s.page;if(Number.isFinite(offset)){let n=0;p=0;while(p+1<pages.length&&n+pages[p].length<=offset){n+=pages[p].length;p++;}}engine.page(Math.max(0,Math.min(p,pages.length-1)));const awards=collection.sync(engine.snapshot());for(const a of awards)if(!pendingAwards.some(x=>x.id===a.id))pendingAwards.push(a);return {state:engine.snapshot(),view:engine.view(),pages,awards};}
  function capture(){const s=snapshot(),p=E.location(s.id),intro=intros.get(p.book+':'+p.chapter);if(s.id===intro&&s.page===0){const starts=read('-chapter-starts')||{};if(!s.privateTestSetup||s.privateTestSetup.chapter!==intro){starts[intro]=s;write('-chapter-starts',starts);}if(p.book>1&&p.chapter===1&&!read('-book'+p.book+'-start'))write('-book'+p.book+'-start',s);}}
  function persist(){if(started){write('-auto',snapshot());capture();}}
  function record(){return {state:snapshot(),aux:Object.fromEntries(['-checkpoint','-book2-start','-book3-start'].map(s=>[s,storage.getItem(key+s)]))};}
  function restoreRecord(r){const before=record();for(const suffix of Object.keys(r.aux))care.protect(suffix);restoreSaved(r.state);checkpointId=r.state.checkpointId||null;try{for(const[s,v]of Object.entries(r.aux)){if(v===null)storage.removeItem(key+s);else storage.setItem(key+s,v)}}catch(e){engine.restore(before.state);for(const[s,v]of Object.entries(before.aux))try{if(v===null)storage.removeItem(key+s);else storage.setItem(key+s,v)}catch{}throw e}refresh(r.state.readingPosition?.offset);}
  function start(){care.protect('-auto');for(const b of [2,3])care.protect('-book'+b+'-start');checkpointId=null;engine.restart();restoreSaved(engine.snapshot());rewind.clear();started=true;storage.removeItem(key+'-book2-start');storage.removeItem(key+'-book3-start');refresh(0);saveCheckpoint();persist();}
  function archiveRaw(suffix,raw){let list;try{list=JSON.parse(storage.getItem(key+'-recovery'))}catch{list=null}if(!Array.isArray(list)||list.some(x=>!x||typeof x.suffix!=='string'||typeof x.raw!=='string')){const r=storage.getItem(key+'-recovery');list=r===null?[]:[{suffix:'-recovery',raw:r}]}if(list.some(x=>x?.suffix===suffix&&x?.raw===raw))return;list.push({suffix,raw});storage.setItem(key+'-recovery',JSON.stringify(list))}
  function index(){const raw=storage.getItem(key+'-checkpoint-index'),saved=read('-checkpoint-index'),ok=saved?.version===1&&saved.records&&typeof saved.records==='object'&&!Array.isArray(saved.records);if(raw!==null&&!ok)archiveRaw('-checkpoint-index',raw);return ok?saved.records:{}}
  function saveCheckpoint(){const records=index();checkpointId='cp-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);const saved=snapshot();records[checkpointId]=saved;const keep=new Set([checkpointId]);for(const suffix of ['-auto','-checkpoint','-previous-checkpoint','-manual','-book2-start','-book3-start',...Array.from({length:30},(_,i)=>'-slot-'+(i+1))]){const r=read(suffix);const id=(r?.state||r)?.checkpointId;if(id){keep.add(id);if(['-checkpoint','-previous-checkpoint'].includes(suffix)&&!records[id])records[id]=r}}for(const id of Object.keys(records))if(!keep.has(id))delete records[id];write('-checkpoint-index',{version:1,records});write('-checkpoint',saved);}
  function validCheckpoint(saved,id){try{if(!saved||(id&&saved.checkpointId!==id))return false;checker.restore(saved);return true}catch{return false}}
  function usableCheckpoint(saved,id){return validCheckpoint(saved,id)&&!checker.view().dead}
  function resolveCheckpoint(saved,suffix){
   const records=index(),id=saved.checkpointId,current=read('-checkpoint'),prior=read('-previous-checkpoint');
   if(id&&records[id]&&!usableCheckpoint(records[id],id)){if(!validCheckpoint(records[id],id))archiveRaw('-checkpoint-index#'+id,JSON.stringify(records[id]));delete records[id];write('-checkpoint-index',{version:1,records});}
   const matching=id&&[records[id],current,prior].find(s=>usableCheckpoint(s,id));
   if(matching){checkpointId=id;write('-checkpoint',matching);return;}
   const adopt=checkpoint=>{if(!checkpoint.checkpointId&&(!prior||prior.checkpointId))write('-previous-checkpoint',checkpoint);checkpointId=checkpoint.checkpointId||'cp-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);const adopted={...checkpoint,checkpointId};records[checkpointId]=adopted;write('-checkpoint-index',{version:1,records});write('-checkpoint',adopted);};
   // Legacy Continue and the stored checkpoint belong to the same live run.
   if(!id&&['-auto','-checkpoint'].includes(suffix)&&usableCheckpoint(current)){adopt(current);return;}
   if(engine.view().dead){
    // Repair old death-screen checkpoints using recorded live states only.
    const where=E.location(saved.id),sameChapter=s=>{const p=s&&E.location(s.id);return p&&p.book===where.book&&p.chapter===where.chapter;};
    const intro=intros.get(where.book+':'+where.chapter),chapter=read('-chapter-starts')?.[intro];
    const safe=[current,prior,chapter].find(s=>usableCheckpoint(s)&&sameChapter(s));
    if(safe){adopt(safe);return;}
    throw Error('This death-screen save has no usable checkpoint. Load another saved game or restart the book. The saved game has not been changed.');
   }
   if(current&&!(prior&&!prior.checkpointId&&current.checkpointId))write('-previous-checkpoint',current);
   checkpointId=null;saveCheckpoint();
  }
  // This death counter belongs to the cumulative achievement store, like upstream.
  // Merge on every restore/restart so a rewound run cannot lag behind the total.
  function restoreSaved(saved){const next=clone(saved),progress=collection.snapshot(),counter='v_ac_b3_ch9_consolation',prize='v_ac_b3_ch9_prize';const count=Math.max(Number(next.vars?.[counter])||0,progress.consolationDeaths||0);if(count>0){next.vars[counter]=count;if(count>=5)next.vars[prize]=progress.earned.includes(prize)?2:Math.max(1,Number(next.vars[prize])||0);if(next.upstream?.awards){next.upstream.awards[counter]=String(count);if(count>=5)next.upstream.awards[prize]=String(next.vars[prize]);}}engine.restore(next);}
  function atomically(fn){
   const keys=['-auto','-checkpoint','-previous-checkpoint','-checkpoint-index','-book2-start','-book3-start','-chapter-starts','-achievements','-recovery'];
   const raw=Object.fromEntries(keys.map(k=>[k,storage.getItem(key+k)])),state=engine.snapshot(),id=checkpointId,wasStarted=started,oldPages=pages,oldAwards=pendingAwards.slice();
   try{return fn()}catch(e){
    // Restore the visible state first; never let a failed load drive old buttons.
    engine.restore(state);checkpointId=id;started=wasStarted;pages=oldPages;pendingAwards=oldAwards;
    const changed=keys.filter(k=>storage.getItem(key+k)!==raw[k]);
    // Free new allocations before restoring the original values at full quota.
    for(const k of changed)storage.removeItem(key+k);
    for(const k of changed)if(raw[k]!==null)storage.setItem(key+k,raw[k]);
    collection=A.create(data,{getItem:k=>storage.getItem(k),setItem:(k,v)=>{care.protect('-achievements');storage.setItem(k,v)}},key+'-achievements');
    throw e;
   }
  }
  function load(suffix){const result=atomically(()=>loadNow(suffix));rewind.clear();return result;}
  function loadNow(suffix){const item=care.status(suffix);if(item.kind==='damaged')throw Error('This saved game is damaged and has not been changed. Your other saves are safe. Export a backup to preserve it.');const r=item.record,s=r?.state||r;if(!s)throw Error('No saved game here yet.');care.protect('-auto');restoreSaved(s);checkpointId=s.checkpointId||null;for(const b of [2,3])care.protect('-book'+b+'-start');if(r?.bookStarts)for(const b of [2,3]){const bs=r.bookStarts[b];if(bs)write('-book'+b+'-start',bs);else storage.removeItem(key+'-book'+b+'-start');}else if(suffix!=='-auto'&&suffix!=='-checkpoint')for(const b of [2,3])storage.removeItem(key+'-book'+b+'-start');started=true;refresh(s.readingPosition?.id===s.id?s.readingPosition.offset:undefined);resolveCheckpoint(s,suffix);persist();}
  function jump(saved,{checkpoint=false}={}){const result=atomically(()=>{care.protect('-auto');restoreSaved(saved);checkpointId=saved.checkpointId||null;started=true;refresh(saved.readingPosition?.offset||0);if(checkpoint)saveCheckpoint();else resolveCheckpoint(saved,'jump');persist();});rewind.clear();return result;}
  function step(){if(engine.snapshot().page>=pages.length-1)return false;rewind.push(record());engine.page(engine.snapshot().page+1);persist();return true;}
  function choose(index){const v=engine.view(),c=v.choices[index];if(!c)throw Error('This choice is unavailable.');if(c.target&&data[c.target]){const from=E.location(v.id).book,to=E.location(c.target).book;if(to>from&&from<=2){const gate=Access.status(collection.catalog,collection.snapshot().earned,from,!!config.achievementGates?.enabled);if(!gate.canContinue)return {blocked:gate};}}
   if(c.special==='restart'){start();return {special:'restart'}};if(c.special==='saves')return {special:'saves'};if(c.special==='checkpoint_load'){load('-checkpoint');return {special:'loaded'}};
   const before=record(),continuation=R.isContinue(v),oldText=prose(v),result=engine.choose(index);if(continuation)rewind.push(before);else rewind.clear();
   refresh(result.special==='stats'&&prose(engine.view())===oldText?before.state.readingPosition.offset:0);if(result.special==='checkpoint_save')saveCheckpoint();persist();return result;
  }
  function back(){const before=record(),r=rewind.pop();if(!r){if(engine.snapshot().page===0)return false;engine.page(engine.snapshot().page-1);persist();return true;}try{restoreRecord(r);persist();return true}catch(e){try{restoreRecord(before)}catch{}rewind.push(r);throw e;}}
  function invest(allocation){const before=record(),text=prose(engine.view());engine.invest(allocation);rewind.push(before);refresh(prose(engine.view())===text?before.state.readingPosition.offset:0);persist();}
  function saveSlot(n,name){if(!Number.isInteger(n)||n<1||n>30)throw Error('Invalid save slot.');write('-slot-'+n,{state:snapshot(),name:String(name||'').slice(0,80),preview:pages[engine.snapshot().page]?.trim().slice(0,200)||'',bookStarts:Object.fromEntries([2,3].map(b=>[b,read('-book'+b+'-start')])),savedAt:new Date().toISOString()});}
  function restartBook(){care.protect('-book3-start');const b=E.location(engine.snapshot().id).book;if(b===1){start();return;}const s=read('-book'+b+'-start');if(!s)throw Error('This save has no recorded book start. Use a named save or test chapter start.');jump(s,{checkpoint:true});if(b===2)storage.removeItem(key+'-book3-start');}
  return {engine,key,test,get collection(){return collection},rewind,read,write,refresh,persist,snapshot,start,load,jump,step,choose,back,invest,saveSlot,restartBook,takeAwards:()=>pendingAwards.splice(0),pages:()=>pages,isStarted:()=>started,setStarted:v=>{started=v},record,saveStatus:care.status,BASE};
 }
 const api={create,paginate,prose,BASE};if(node)module.exports=api;else root.MagiumTextModel=api;
})(typeof globalThis!=='undefined'?globalThis:this);
