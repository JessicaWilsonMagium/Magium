/* Preserve unreadable records before replacement; no story changes. */
(function(root){
 const BASE='magium-text-edition-v1';
 function create(storage,validate){
  const parse=s=>{try{return JSON.parse(storage.getItem(BASE+s))}catch{return null}};
  function status(s){const raw=storage.getItem(BASE+s);if(raw===null)return {kind:'empty',raw:null,record:null};try{const record=JSON.parse(raw);if(s==='-achievements'){if(record?.version!==1||!Array.isArray(record.earned)||record.earned.some(x=>typeof x!=='string'||!/^v_ac_[a-zA-Z0-9_]+$/.test(x))||(record.consolationDeaths!==undefined&&(!Number.isSafeInteger(record.consolationDeaths)||record.consolationDeaths<0)))throw Error('Invalid achievements');}else validate(record?.state||record);return {kind:'valid',raw,record}}catch(e){return {kind:'damaged',raw,record:null,error:e.message}}}
  function protect(s){const item=status(s);if(item.kind!=='damaged')return;let saved=parse('-recovery');if(!Array.isArray(saved)||saved.some(x=>!x||typeof x.suffix!=='string'||typeof x.raw!=='string')){const raw=storage.getItem(BASE+'-recovery');saved=raw===null?[]:[{suffix:'-recovery',raw}];}if(saved.some(x=>x.suffix===s&&x.raw===item.raw))return;saved.push({suffix:s,raw:item.raw});try{storage.setItem(BASE+'-recovery',JSON.stringify(saved))}catch{throw Error('This damaged save could not be preserved. Nothing has overwritten it. Export a backup before trying again.')}}
  return {status,protect};
 }
 const api={create};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MagiumSaveCare=api;
})(typeof globalThis!=='undefined'?globalThis:this);
