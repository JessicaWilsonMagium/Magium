// C1 property test (0.2.12+): random play with saves, loads, Back, new games, deaths, cold resumes and
// export/import. Invariant: loading a slot restores exactly the checkpoint that was current when it was saved;
// cold Continue never changes the checkpoint; a death returns to the current checkpoint.
const {M,B,E,D,F,real,Storage,clone}=require('./common.cjs');
const seeds=Number(process.argv[3]||4),steps=Number(process.argv[4]||200),K='magium-text-edition-v1';
let rnd=1;const rand=n=>{rnd=(rnd*1103515245+12345)%2147483648;return rnd%n};
const v=E.create(D),validate=x=>v.restore(x);const fails=new Map(),note=(k,d)=>{if(!fails.has(k))fails.set(k,{n:0,d});fails.get(k).n++};
const cpKey=st=>{const c=JSON.parse(st.getItem(K+'-checkpoint'));return c.id+'|'+JSON.stringify(c.vars)};
const starts=Object.keys(F);let checks=0,loads=0,deaths=0,imports=0;
for(let seed=1;seed<=seeds;seed++){rnd=seed*104729;let st=new Storage,m=M.create(D,st);m.jump(real(starts[rand(starts.length)]),{checkpoint:true});const expect={};
 for(let k=0;k<steps;k++){const r=rand(100),view=m.engine.view();
  try{
   if(r<6){const n=1+rand(30);m.saveSlot(n,'s');expect[n]=cpKey(st);}
   else if(r<11&&Object.keys(expect).length){const ns=Object.keys(expect),n=ns[rand(ns.length)];m.load('-slot-'+n);loads++;checks++;if(cpKey(st)!==expect[n])note('slot load restores its checkpoint',m.engine.view().id);}
   else if(r<13){const before=cpKey(st),m2=M.create(D,st);m2.load('-auto');checks++;if(cpKey(st)!==before)note('cold Continue changes checkpoint',m2.engine.view().id);m=m2;}
   else if(r<14){m.jump(real(starts[rand(starts.length)]),{checkpoint:true});}
   else if(r<15){m.start();}
   else if(r<17){const src=B.create(st,validate,34,{catalog:m.collection.catalog,collection:m.collection.snapshot()}),dst=new Storage;B.restore(dst,B.parse(src,validate),validate);st=dst;m=M.create(D,st);m.load('-auto');imports++;
     for(const n of Object.keys(expect)){const mm=M.create(D,st);mm.load('-slot-'+n);checks++;if(cpKey(st)!==expect[n])note('after export/import, slot load restores its checkpoint',n);}m=M.create(D,st);m.load('-auto');}
   else if(r<22&&m.rewind.canBack()){m.back();if(m.engine.pendingStats()){m.engine.statsOpened();m.invest({});}}
   else if(view.dead){const i=view.choices.findIndex(c=>c.special==='checkpoint_load');if(i<0){m.start();continue}const target=JSON.parse(st.getItem(K+'-checkpoint')).id;m.choose(i);deaths++;checks++;if(m.engine.view().id!==target)note('death returns to current checkpoint',target);}
   else{const opts=view.choices.map((c,i)=>[c,i]).filter(([c])=>c.target&&D[c.target]&&!['restart','saves','checkpoint_load'].includes(c.special));if(!opts.length){m.start();continue}
     const [,i]=opts[rand(opts.length)];const res=m.choose(i);if(res.special==='stats')m.invest({});}
  }catch(e){note('error: '+e.message,view.id)}}}
console.log('checks',checks,'| slot loads',loads,'| deaths',deaths,'| export/import cycles',imports);for(const[k,x]of fails)console.log('FAIL',k,'x'+x.n,'e.g.',x.d);if(!fails.size)console.log('no failures');
