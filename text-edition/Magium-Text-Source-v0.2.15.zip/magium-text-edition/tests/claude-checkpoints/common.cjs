// Shared harness. Usage: node repro/X.cjs <path-to-magium-text-edition>
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(process.argv[2]||'.');
const E=require(root+'/src/engine'),M=require(root+'/src/model'),B=require(root+'/src/backup'),O=require(root+'/src/original-runtime');
const clone=x=>JSON.parse(JSON.stringify(x));
const D=clone(vm.runInNewContext(fs.readFileSync(root+'/src/data.js','utf8')+';ORIGINAL_SCENES'));
const F=clone(vm.runInNewContext(fs.readFileSync(root+'/tests/legacy-fixtures.js','utf8')+';MAGIUM_TEST_FIXTURES'));
class Storage{constructor(){this.map=new Map}getItem(k){return this.map.has(k)?this.map.get(k):null}setItem(k,v){this.map.set(k,String(v))}removeItem(k){this.map.delete(k)}dump(){return JSON.stringify([...this.map].sort())}}
// A chapter-start fixture made to look like a real run (no test markers).
function real(id){const s=clone(F[id]);delete s.privateTestSetup;delete s.upstream;s.page=0;s.readingPosition={id:s.id,offset:0};return s;}
// Choose the visible choice leading to target (throws if absent).
function go(m,target){const v=m.engine.view(),i=v.choices.findIndex(c=>c.target===target);if(i<0)throw Error('No choice to '+target+' from '+v.id+': '+v.choices.map(c=>c.target).join(','));return m.choose(i);}
function special(m,kind){const v=m.engine.view(),i=v.choices.findIndex(c=>c.special===kind);if(i<0)throw Error('No '+kind+' choice at '+v.id);return m.choose(i);}
let failures=0;function check(label,cond,detail=''){console.log((cond?'ok   ':'FAIL ')+label+(detail?'  — '+detail:''));if(!cond)failures++;}
process.on('exit',()=>{if(failures)process.exitCode=1});
module.exports={root,E,M,B,O,D,F,clone,Storage,real,go,special,check};
