const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const {JSDOM,VirtualConsole}=require('jsdom'),root=path.resolve(__dirname,'..'),E=require('../src/engine'),M=require('../src/model'),B=require('../src/backup');
const clone=x=>JSON.parse(JSON.stringify(x)),D=clone(vm.runInNewContext(fs.readFileSync(root+'/src/data.js','utf8')+';ORIGINAL_SCENES')),F=clone(vm.runInNewContext(fs.readFileSync(__dirname+'/legacy-fixtures.js','utf8')+';MAGIUM_TEST_FIXTURES'));
class Storage{constructor(){this.map=new Map}getItem(k){return this.map.get(k)??null}setItem(k,v){this.map.set(k,String(v))}removeItem(k){this.map.delete(k)}}
const validate=s=>E.create(D).restore(s),K=M.BASE;
function boot(records={}){const html=fs.readFileSync(root+'/src/index.html','utf8'),vc=new VirtualConsole,errors=[];vc.on('jsdomError',e=>errors.push(e.message));const dom=new JSDOM(html,{url:'https://appassets.androidplatform.net/assets/index.html',runScripts:'outside-only',virtualConsole:vc}),w=dom.window;w.TextEncoder=TextEncoder;w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');this.dispatchEvent(new w.Event('close'))};for(const[k,v]of Object.entries(records))w.localStorage.setItem(k,v);for(const[,n]of html.matchAll(/<script src="([^"]+)"/g))vm.runInContext(fs.readFileSync(root+'/src/'+n,'utf8'),dom.getInternalVMContext());assert.deepEqual(errors,[]);return {dom,d:w.document,w,m:w.MagiumText.model}}
test('Each named save restores its own checkpoint after another game, including backup import',()=>{
 const st=new Storage,m=M.create(D,st);m.jump(F['B3-Ch05a-Intro'],{checkpoint:true});const cp=m.read('-checkpoint');m.step();m.saveSlot(1,'Book 3');m.start();m.load('-slot-1');assert.equal(m.read('-checkpoint').id,cp.id);assert.equal(m.read('-checkpoint').checkpointId,cp.checkpointId);m.load('-checkpoint');assert.equal(m.snapshot().id,cp.id);const dest=new Storage;B.restore(dest,B.parse(B.create(st,validate,34),validate),validate);const cold=M.create(D,dest);cold.start();cold.load('-slot-1');cold.load('-checkpoint');assert.equal(cold.snapshot().id,cp.id);
});
test('Legacy saved record is never rewritten; fallback uses loaded point and preserves previous checkpoint',()=>{
 const st=new Storage,m=M.create(D,st);m.start();const previous=m.read('-checkpoint'),legacy=JSON.stringify(F['B3-Ch05a-Intro']);st.setItem(K+'-slot-1',legacy);m.load('-slot-1');assert.equal(st.getItem(K+'-slot-1'),legacy);assert.equal(m.read('-checkpoint').id,F['B3-Ch05a-Intro'].id);assert.equal(m.read('-previous-checkpoint').id,previous.id);m.load('-previous-checkpoint');assert.equal(m.snapshot().id,previous.id);
});
test('Back after a newly reached checkpoint returns to the earlier linked checkpoint',()=>{
 const m=M.create(D,new Storage);m.start();const old=m.read('-checkpoint');const record=m.record();m.jump(F['B2-Ch05a-Intro'],{checkpoint:true});m.rewind.push(record);assert(m.back());m.load('-checkpoint');assert.equal(m.snapshot().id,old.id);
});
test('Damaged auto and named save are archived before New Game or overwrite',()=>{
 const st=new Storage,m=M.create(D,st),bad='{"state":';st.setItem(K+'-auto',bad);st.setItem(K+'-slot-3',bad);assert.equal(m.saveStatus('-auto').kind,'damaged');m.start();m.saveSlot(3,'New');const recovered=JSON.parse(st.getItem(K+'-recovery'));assert(recovered.some(x=>x.suffix==='-auto'&&x.raw===bad));assert(recovered.some(x=>x.suffix==='-slot-3'&&x.raw===bad));
});
test('If recovery copy cannot be stored, New Game refuses before altering any save',()=>{
 const st=new Storage,m=M.create(D,st);st.setItem(K+'-auto','{broken');const before=new Map(st.map),set=st.setItem.bind(st);st.setItem=(k,v)=>{if(k===K+'-recovery')throw Error('Quota');set(k,v)};assert.throws(()=>m.start(),/could not be preserved/);assert.deepEqual(st.map,before);
});
test('Backup exports good slots plus exact raw damaged records; imports retain both',()=>{
 const st=new Storage,m=M.create(D,st);m.start();m.saveSlot(1,'Good');st.setItem(K+'-slot-9','{broken');const backup=B.parse(B.create(st,validate,34),validate);assert(backup.records['-slot-1']);assert.equal(backup.records['-slot-9'],null);assert.equal(backup.damaged['-slot-9'],'{broken');assert(backup.skipped.includes('-slot-9'));const dest=new Storage;B.restore(dest,backup,validate);assert(JSON.parse(dest.getItem(K+'-recovery')).some(x=>x.suffix==='-slot-9'&&x.raw==='{broken'));assert(JSON.parse(dest.getItem(K+'-slot-1')).name==='Good');
});
test('Import rebuilds unreadable local achievements from saved awards and preserves their damaged raw record',()=>{
 const st=new Storage,m=M.create(D,st);m.start();const s=m.snapshot();s.vars.v_ac_ch1_coward=2;st.setItem(K+'-slot-1',JSON.stringify({state:s,name:'Award'}));st.setItem(K+'-achievements','{broken');const source=new Storage;M.create(D,source).start();B.restore(st,B.parse(B.create(source,validate,34),validate),validate);assert(JSON.parse(st.getItem(K+'-achievements')).earned.includes('v_ac_ch1_coward'));assert(JSON.parse(st.getItem(K+'-recovery')).some(x=>x.suffix==='-achievements'&&x.raw==='{broken'));
});
test('UI labels damaged slots and offers automatic-save recovery without deleting their data',()=>{
 const bad='{broken',b=boot({[K+'-auto']:bad,[K+'-slot-3']:bad});try{b.d.getElementById('continueButton').click();assert(b.d.getElementById('confirmDialog').open);assert(b.d.getElementById('confirmDescription').textContent.includes('other saves are safe'));b.d.getElementById('confirmDialog').close();b.d.getElementById('loadButton').click();assert(b.d.querySelector('[data-slot="3"]').textContent.includes('Damaged'));assert.equal(b.w.localStorage.getItem(K+'-auto'),bad)}finally{b.dom.window.close()}
});
test('A checkpoint restored through Back remains available after saving and starting a new game',()=>{
 const m=M.create(D,new Storage);m.start();const original=m.read('-checkpoint'),record=m.record();m.jump(F['B3-Ch05a-Intro'],{checkpoint:true});m.rewind.push(record);m.back();m.saveSlot(1,'Rewound');m.start();m.load('-slot-1');m.load('-checkpoint');assert.equal(m.snapshot().checkpointId,original.checkpointId);assert.equal(m.snapshot().id,original.id);
});
test('Thirty late saves with distinct linked checkpoints fit the backup limit and older parsers accept extra fields',()=>{
 const st=new Storage,m=M.create(D,st);m.jump(F['B2-Ch01a-Intro'],{checkpoint:true});m.jump(F['B3-Ch01a-Intro'],{checkpoint:true});for(let i=1;i<=30;i++){m.jump(F['B3-Ch12a-Intro'],{checkpoint:true});m.saveSlot(i,'Checkpoint '+i)}const text=B.create(st,validate,34);assert(Buffer.byteLength(text)<=B.LIMIT);const backup=B.parse(text,validate);assert(Object.keys(backup.checkpointIndex).length>=30);const old=require('./legacy-backup-0.2.9.cjs');assert.doesNotThrow(()=>old.parse(text,validate));
});
test('Native export confirmation and errors remain visible inside the open Backup dialog',()=>{
 const b=boot();try{
 b.m.start();let calls=0;b.w.MagiumTextFiles={save(){calls++}};
 b.d.getElementById('backupButton').click();b.d.getElementById('exportBackup').click();
 const status=b.d.getElementById('backupStatus');assert.equal(calls,1);assert.equal(status.hidden,false);assert(status.textContent.includes('Choose a location'));assert(!status.textContent.includes('Backup exported.'));
 b.w.MagiumText.notice('Backup exported.');assert.equal(status.textContent,'Backup exported.');assert(b.d.getElementById('backupDialog').contains(status));assert(b.d.getElementById('backupDialog').open);
 b.d.getElementById('exportBackup').click();assert(!status.textContent.includes('Backup exported.'));
 b.w.MagiumText.notice('The backup file could not be read or written.');assert.equal(status.textContent,'The backup file could not be read or written.');
 b.d.getElementById('backupButton').click();assert(status.hidden);assert.equal(status.textContent,'');
 }finally{b.dom.window.close()}
});
// Legacy storage has the same story state but no per-save checkpoint metadata.
function makeLegacy(st){for(const[k,raw]of st.map){if(k.endsWith('-checkpoint-index')||k.endsWith('-previous-checkpoint')){st.removeItem(k);continue}try{const x=JSON.parse(raw);delete x.checkpointId;if(x.state)delete x.state.checkpointId;st.setItem(k,JSON.stringify(x))}catch{}}}
function goTo(m,target){const i=m.engine.view().choices.findIndex(c=>c.target===target);assert(i>=0,'route to '+target);m.choose(i)}
const deathRoute=['B3-Ch09a-Intro2','B3-Ch09a-Jack','B3-Ch09a-Delay','B3-Ch09a-Currents','B3-Ch09a-Gregory','B3-Ch09a-Jumping','B3-Ch09a-Carcasses','B3-Ch09a-Warning','B3-Ch09a-Breathe'];
function startCh9(st){const m=M.create(D,st);m.jump(F['B3-Ch09a-Intro'],{checkpoint:true});return m}
test('Legacy death-screen Continue retains a live checkpoint and the death button leaves death',()=>{
 const st=new Storage,old=startCh9(st);for(const target of deathRoute)goTo(old,target);makeLegacy(st);
 const m=M.create(D,st);m.load('-auto');assert(m.engine.view().dead);assert.equal(m.read('-checkpoint').id,'B3-Ch09a-Intro');assert(m.read('-checkpoint').checkpointId);
 m.choose(m.engine.view().choices.findIndex(c=>c.special==='checkpoint_load'));assert(!m.engine.view().dead);assert.equal(m.snapshot().id,'B3-Ch09a-Intro');
});
test('Legacy mid-chapter Resume preserves the original checkpoint, including after two legacy slot loads',()=>{
 const st=new Storage,m=startCh9(st);m.saveSlot(1,'Old A');goTo(m,deathRoute[0]);m.saveSlot(2,'Old B');for(const target of deathRoute.slice(1,5))goTo(m,target);makeLegacy(st);
 const cold=M.create(D,st);cold.load('-auto');const cp=cold.read('-checkpoint');assert.equal(cp.id,'B3-Ch09a-Intro');for(const target of deathRoute.slice(5))goTo(cold,target);cold.load('-checkpoint');assert.equal(cold.snapshot().id,'B3-Ch09a-Intro');
 cold.load('-slot-1');cold.load('-slot-2');const available=[cold.read('-checkpoint'),cold.read('-previous-checkpoint'),...Object.values(cold.read('-checkpoint-index').records)];assert(available.some(s=>s?.id===cp.id&&JSON.stringify(s.vars)===JSON.stringify(cp.vars)));
});
test('Already poisoned 0.2.12 death checkpoint uses a recorded live previous checkpoint',()=>{
 const st=new Storage,m=startCh9(st),live=m.read('-checkpoint');for(const target of deathRoute)goTo(m,target);
 const dead={...m.snapshot(),checkpointId:'cp-poison'};st.setItem(K+'-auto',JSON.stringify(dead));st.setItem(K+'-checkpoint',JSON.stringify(dead));st.setItem(K+'-previous-checkpoint',JSON.stringify(live));st.setItem(K+'-checkpoint-index',JSON.stringify({version:1,records:{'cp-poison':dead}}));
 const cold=M.create(D,st);cold.load('-auto');cold.load('-checkpoint');assert(!cold.engine.view().dead);assert.equal(cold.snapshot().id,live.id);
});
test('An orphan death save cannot replace a checkpoint with another death',()=>{
 const source=new Storage,m=startCh9(source);for(const target of deathRoute)goTo(m,target);const dead=m.snapshot();delete dead.checkpointId;
 const st=new Storage,n=M.create(D,st);n.start();st.setItem(K+'-slot-1',JSON.stringify(dead));const before=n.snapshot(),raw=new Map(st.map);assert.throws(()=>n.load('-slot-1'),/no usable checkpoint/);assert.deepEqual(n.snapshot(),before);assert.deepEqual(st.map,raw);
});
test('A quota failure after intermediate load writes restores state, text, storage, awards and Back history',()=>{
 const st=new Storage,m=M.create(D,st);m.jump(F['B2-Ch05a-Intro'],{checkpoint:true});m.saveSlot(1,'Target');m.jump(F['B3-Ch05a-Intro'],{checkpoint:true});m.step();
 const before=m.snapshot(),text=m.engine.view(),raw=new Map(st.map),awards=m.collection.snapshot(),history=m.rewind.canBack(),set=st.setItem.bind(st);let failed=false;
 st.setItem=(k,v)=>{if(!failed&&k===K+'-auto'){failed=true;throw Error('QuotaExceededError')}set(k,v)};
 assert.throws(()=>m.load('-slot-1'),/Quota/);assert.deepEqual(m.snapshot(),before);assert.deepEqual(m.engine.view(),text);assert.deepEqual(st.map,raw);assert.deepEqual(m.collection.snapshot(),awards);assert.equal(m.rewind.canBack(),history);
});
test('A failed jump restores the original state, pages and all auxiliary records',()=>{
 const st=new Storage,m=M.create(D,st);m.start();const before=m.snapshot(),raw=new Map(st.map),pages=m.pages(),set=st.setItem.bind(st);let failed=false;st.setItem=(k,v)=>{if(!failed&&k===K+'-auto'){failed=true;throw Error('Quota')}set(k,v)};
 assert.throws(()=>m.jump(F['B3-Ch05a-Intro'],{checkpoint:true}),/Quota/);assert.deepEqual(m.snapshot(),before);assert.deepEqual(m.pages(),pages);assert.deepEqual(st.map,raw);
});
test('An invalid linked checkpoint falls back safely and its raw index is preserved',()=>{
 const st=new Storage,m=M.create(D,st);m.jump(F['B2-Ch05a-Intro'],{checkpoint:true});m.saveSlot(1,'Target');const id=m.snapshot().checkpointId;m.start();const ix=m.read('-checkpoint-index');ix.records[id].vars.v_strength=9;const bad=JSON.stringify(ix);st.setItem(K+'-checkpoint-index',bad);m.load('-slot-1');assert.equal(m.snapshot().id,'B2-Ch05a-Intro');assert(m.read('-recovery').some(x=>x.suffix==='-checkpoint-index#'+id&&x.raw===JSON.stringify(ix.records[id])));assert.doesNotThrow(()=>B.create(st,validate,34));
});
test('Unreadable checkpoint index is archived before replacement; if archive fails nothing is overwritten',()=>{
 const st=new Storage,m=M.create(D,st);m.start();const bad='{"version":1,"records":{';st.setItem(K+'-checkpoint-index',bad);m.jump(F['B2-Ch05a-Intro'],{checkpoint:true});assert(m.read('-recovery').some(x=>x.suffix==='-checkpoint-index'&&x.raw===bad));
 st.setItem(K+'-checkpoint-index',bad);st.removeItem(K+'-recovery');const before=m.snapshot(),raw=new Map(st.map),set=st.setItem.bind(st);st.setItem=(k,v)=>{if(k===K+'-recovery')throw Error('Quota');set(k,v)};assert.throws(()=>m.jump(F['B3-Ch05a-Intro'],{checkpoint:true}),/Quota/);assert.deepEqual(m.snapshot(),before);assert.deepEqual(st.map,raw);
});
test('Repairing a death checkpoint among thirty linked saves does not duplicate the index or block export',()=>{
 const st=new Storage,m=startCh9(st),live=m.read('-checkpoint');for(const target of deathRoute)goTo(m,target);const dead={...m.snapshot(),checkpointId:'cp-poison'};
 m.saveSlot(30,'Death');const slot=m.read('-slot-30');slot.state=dead;st.setItem(K+'-slot-30',JSON.stringify(slot));
 for(let n=1;n<30;n++){m.jump(F['B3-Ch12a-Intro'],{checkpoint:true});m.saveSlot(n,'Late '+n)}
 const ix=m.read('-checkpoint-index');ix.records['cp-poison']=dead;st.setItem(K+'-checkpoint-index',JSON.stringify(ix));st.setItem(K+'-previous-checkpoint',JSON.stringify(live));
 m.load('-slot-30');assert.equal(m.read('-checkpoint').id,live.id);assert.equal(m.read('-recovery'),null);const text=B.create(st,validate,34);assert(Buffer.byteLength(text)<=B.LIMIT);const data=B.parse(text,validate);assert.equal(B.summary(data).slots,30);assert(!data.omittedExtras);
});
test('Oversized recovery copies are omitted from export with an explicit notice, leaving local data untouched',()=>{
 const st=new Storage,m=M.create(D,st);m.start();m.saveSlot(1,'Keep');const raw=JSON.stringify([{suffix:'-checkpoint-index',raw:'x'.repeat(B.LIMIT)}]);st.setItem(K+'-recovery',raw);const before=new Map(st.map);
 const text=B.create(st,validate,34),data=B.parse(text,validate);assert.equal(data.omittedExtras.recoveryCopies,1);assert.equal(data.omittedExtras.checkpointEntries,0);assert.equal(data.records['-slot-1'].name,'Keep');assert.deepEqual(st.map,before);assert(B.exportNotice(data).includes('remain only on the exporting device'));assert.doesNotThrow(()=>require('./legacy-backup-0.2.9.cjs').parse(text,validate));
 const dest=new Storage;B.restore(dest,data,validate);assert.equal(JSON.parse(dest.getItem(K+'-slot-1')).name,'Keep');
});
test('Oversized checkpoint metadata is trimmed before rejecting readable saves and achievements',()=>{
 const st=new Storage,m=M.create(D,st);m.jump(F['B3-Ch12a-Intro'],{checkpoint:true});m.saveSlot(1,'Keep');const cp=m.read('-checkpoint'),ix=m.read('-checkpoint-index');
 for(let n=0;n<150;n++){const id='cp-extra-'+n;ix.records[id]={...cp,checkpointId:id}}
 st.setItem(K+'-checkpoint-index',JSON.stringify(ix));const before=new Map(st.map);const text=B.create(st,validate,34),data=B.parse(text,validate);assert(data.omittedExtras.checkpointEntries>0);assert.equal(data.records['-slot-1'].name,'Keep');assert.deepEqual(clone(data.records['-achievements']),clone(m.collection.snapshot()));assert.deepEqual(st.map,before);assert(Buffer.byteLength(text)<=B.LIMIT);assert(B.exportNotice(data).includes('checkpoint history'));
});
test('Size fallback never drops raw damaged normal saves just to make an export fit',()=>{
 const st=new Storage,m=M.create(D,st);m.start();st.setItem(K+'-slot-2','{'+ 'x'.repeat(B.LIMIT));const before=new Map(st.map);assert.throws(()=>B.create(st,validate,34),/2 MB/);assert.deepEqual(st.map,before);
});
test('Export omission warning remains visible through native success and appears in import summary',()=>{
 const b=boot();try{b.m.start();b.w.localStorage.setItem(K+'-recovery',JSON.stringify([{suffix:'-checkpoint-index',raw:'x'.repeat(B.LIMIT)}]));let exported;b.w.MagiumTextFiles={save(name,text){exported=text}};
 b.d.getElementById('backupButton').click();b.d.getElementById('exportBackup').click();assert(b.d.getElementById('backupStatus').textContent.includes('older recovery copies'));b.w.MagiumText.notice('Backup exported.');assert(b.d.getElementById('backupStatus').textContent.startsWith('Backup exported.'));assert(b.d.getElementById('backupStatus').textContent.includes('older recovery copies'));
 b.w.MagiumText.receiveBackup(exported);assert(b.d.getElementById('backupSummary').textContent.includes('older recovery copies'));
 }finally{b.dom.window.close()}
});
test('Each storage-failure load case starts from its own unchanged baseline',()=>{
 for(const suffix of ['-checkpoint-index','-previous-checkpoint','-book2-start','-checkpoint','-auto','-chapter-starts']){
  const st=new Storage,old=M.create(D,st);old.jump(F['B2-Ch01a-Intro'],{checkpoint:true});old.jump(F['B2-Ch05a-Intro'],{checkpoint:true});old.saveSlot(1,'Legacy');old.jump(F['B3-Ch05a-Intro'],{checkpoint:true});makeLegacy(st);
  const m=M.create(D,st);m.load('-auto');m.step();m.takeAwards();const before=m.snapshot(),view=m.engine.view(),raw=new Map(st.map),awards=m.collection.snapshot(),history=m.rewind.canBack(),set=st.setItem.bind(st);let failed=false;
  st.setItem=(k,v)=>{if(k===K+suffix){failed=true;throw Error('Quota')}set(k,v)};
  let error;try{m.load('-slot-1')}catch(e){error=e}
  if(failed){assert(error);assert.deepEqual(m.snapshot(),before,suffix);assert.deepEqual(m.engine.view(),view,suffix);assert.deepEqual(st.map,raw,suffix);assert.deepEqual(m.collection.snapshot(),awards,suffix);assert.equal(m.rewind.canBack(),history,suffix);assert.equal(m.takeAwards().length,0)}
 }
});
test('Export keeps the only recovery copy of overwritten progress ahead of unreferenced checkpoint history',()=>{
 const st=new Storage,m=M.create(D,st);m.jump(F['B3-Ch12a-Intro'],{checkpoint:true});m.saveSlot(1,'Keep');
 const damaged='{"state":'+st.getItem(K+'-slot-1').slice(9,-20);st.setItem(K+'-slot-2',damaged);m.saveSlot(2,'Replacement');
 const ix=m.read('-checkpoint-index'),cp=m.read('-checkpoint');for(let n=0;n<150;n++){const id='cp-history-'+n;ix.records[id]={...cp,checkpointId:id}}
 st.setItem(K+'-checkpoint-index',JSON.stringify(ix));const before=new Map(st.map),data=B.parse(B.create(st,validate,34),validate);assert(data.omittedExtras.checkpointEntries>0);assert.equal(data.omittedExtras.recoveryCopies,0);assert(data.recoveryRaw.some(x=>x.suffix==='-slot-2'&&x.raw===damaged));assert.deepEqual(st.map,before);
 const dest=new Storage;B.restore(dest,data,validate);assert(JSON.parse(dest.getItem(K+'-recovery')).some(x=>x.suffix==='-slot-2'&&x.raw===damaged));
});
test('Future omission counters are accepted while known counters still reject invalid values',()=>{
 const st=new Storage,m=M.create(D,st);m.start();const data=JSON.parse(B.create(st,validate,34));data.omittedExtras={recoveryCopies:0,checkpointEntries:1,futureCounter:2};assert.doesNotThrow(()=>B.parse(JSON.stringify(data),validate));
 for(const value of [-1,1.5,'1',null]){data.omittedExtras.recoveryCopies=value;assert.throws(()=>B.parse(JSON.stringify(data),validate),/export summary/)}
});
