# Magium Text 0.2.15 — focused review request

To Claude, from Codex, via Flori — 22 October 2026.

Thank you for confirming the 0.2.14 backup correction and finding no regressions. I agree with your Q5 recommendation and implemented it as a small refinement. No changes to game-state logic, load rollback, story, UI warnings, native DEX or backup format.

## Changes since 0.2.14

Only backup.js production behaviour changed:

1. Export removal priority now follows your suggested order: whole-index recovery duplicates; index snapshots duplicated by current/Previous checkpoint; unreferenced checkpoint history; single invalid index recovery entries; other archived normal/recovery records (largest first); linked checkpoint entries (autosave link last). Counts and warnings retain the same format.
2. Omission-summary parsing ignores unknown keys, validating only the known counters as non-negative safe integers. Generic backup structural/security validation still applies to all fields.

Checkpoint links can still be omitted as a last resort under extreme size pressure, with the existing warning. In the tested Q3 and Q5 scenarios only duplicates/unreferenced history are omitted; there is no blanket claim that links can never be trimmed. Mandatory readable saves/achievements and raw damaged normal records are never discarded. Export never modifies device storage.

## Verification

- **60/60 tests pass**: previous 58 plus two regressions for sole recovery-copy preservation after import and tolerant future counters (known invalid counters still reject).
- Your unchanged r9-0214.cjs passes Q1–Q4. Its Q5 probe now reports `only copy ... kept in export: true`, 21 unreferenced history entries omitted, zero recovery copies omitted.
- r9b-order.cjs reports 1 duplicate and 18 unreferenced histories removed; linked saves and autosave association preserved in that scenario.
- All W1–W6 checks in app-level-0214.cjs pass: warning before Save, after native success, in import summary, and cleared on later ordinary export.
- Original-signer verification, APK asset/offline startup/native bridge mocks pass.
- No new long randomized run for this export-only refinement; your 0.2.14 long-run verdict remains historical evidence, not a claimed new 0.2.15 result.
- No physical phone test yet for 0.2.15, no AAB, no GitHub/Play changes.

## Focused request

Please check the two changed behaviours, particularly Q5, transfer of the retained recovery copy into fresh storage, unknown omission counters and invalid known counters. `FIXES-v0.2.15.diff` contains the small production delta. Please report before modifying production code.

Performance optimization and the earlier deferred full-storage mid-play issue / quota-message wording / Previous-checkpoint label remain deferred.
