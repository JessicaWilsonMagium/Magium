# Magium Text Edition — 0.2.2

Public text-only build of Cristian Mihailescu's original interactive Books 1–3,
with Thuiop's execution routines and our reading interface. All 34 chapters are
included. No illustrations or audio. No testing tools. Book progression is unlocked.

## Install and saves

Install Magium-Text-Edition-v0.2.2.apk as an update to Magium Text. Package, signer,
WebView origin and existing save keys are preserved. Press Resume or load a named
slot to continue. The Stats button stays disabled on the title screen until a run
is resumed or loaded, preventing the misleading zero stats found during testing.

The separate Magium Engine Test app and its testing saves remain independent.
Flori may continue playing that version. This build does not update the private
website. Export/import JSON transfers a copy of normal saves between editions.

Normal Back returns across pages and Continue, stopping at real choices. Next
changes to Choose above when a choice is required. There are 30 named save slots,
checkpoints, achievements, reading settings, backup export/import and portrait
flipping. All included books remain unlocked; the future 25-achievement settings
are present but disabled, as previously requested.

Read ADAPTER.md for the two deliberately retained compatibility fixes, exact
upstream boundaries and legacy save reconstruction limitations. This is a signed
public build prepared for distribution; no Google Play upload has been performed.

## Rebuild web files and run tests

Node 18+ and Python 3 are required. Install development dependencies and build:

```sh
npm ci
npm run build
npm test
npm run compare
```

The HTML in dist is self-contained. The APK packages individual bundled files
once. tools/build.cjs uses the unmodified vendored parser and embeds unchanged
upstream routine bodies in the documented offline wrappers. Vendored story and
runtime files are pinned; no network access is needed to run the game.

## Build Android

Requires Java 17, Android build-tools 36.0.0 and platform 36. Use the original
private key; set MAGIUM_STORE_PASS, MAGIUM_KEY_PASS and MAGIUM_KEY_ALIAS privately
in the environment. Never put their values in source or build commands.

```sh
python3 tools/build-android.py \
  --build-tools /path/to/android-sdk/build-tools/36.0.0 \
  --android-jar /path/to/android-sdk/platforms/android-36/android.jar \
  --keystore /private/path/test.keystore
npm run verify-apk
```

The native DEX is reused unchanged from the verified 0.1.3 text APK. It is a pinned
binary build input; this archive reproduces packaging rather than compilation of
that DEX. It retains the existing WebView, JSON picker and portrait sensor logic.
The Android package is org.magium.textedition, versionCode 5, versionName 0.2.2.
Signing materials are not included. Check VALIDATION.md and tests/ for evidence.
The final production APK itself has not yet been executed on a physical device.

The Full immersion falling-stat display is restored in Book 1 Chapter 6.
Only the displayed numbers animate; real stats and saves remain unchanged.
The experimental app also receives this same presentation module as 0.1.1-lab.

Current update: original Magium logo, default reading size 20 for fresh preferences, and read-only Magical power / Magical knowledge values controlled by the original v_b3_ch11_magic flag. Existing saved preferences survive. VN save compatibility claims removed. Target SDK 36; original native DEX and save identity retained. Android predictive Back is temporarily opted out as documented by Android, preserving the existing onBackPressed bridge. Phone install/update and Android 16 system Back appearance checks remain necessary.

Optional Play AAB: add --bundletool /path/to/bundletool-all.jar to the Android build command. Requires a full JDK including jarsigner and Android build-tools with aapt2. No upload occurs.

APK asset verification uses Python Pillow to verify that Android PNG processing preserves every logo pixel.
