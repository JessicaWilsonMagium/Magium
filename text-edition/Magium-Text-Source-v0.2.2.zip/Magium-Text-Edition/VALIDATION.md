# 0.2.2 verification

APK: Magium-Text-Edition-v0.2.2.apk; 2,381,671 bytes; SHA-256 69077771830459cb12f85f23fdcb67ec940ebcea203c206955133203a36d0c2d.
Version code 5; target SDK 36; minimum SDK 26; original signer verified.
Native DEX, package identity, HTTPS app-assets origin and save keys preserved.

21 focused tests pass, including new defaults/preferences, exact original logo,
and locked/unlocked read-only late Book 3 magic fields. Packaged assets boot
at the exact native origin in jsdom; save/reload and document bridge mocks pass.
Original logo pixels survive Android PNG processing unchanged.

Story data, engine, model, backup, rewind, achievements, original runtime and
countdown modules match the preceding release byte-for-byte. See provenance-report.json.
The prior complete original-reference comparison and its logs remain applicable:
2,159 scenes; 16,179 entries; 14,846 transitions; 16,148 valid roundtrips; zero
unexpected mismatches with the two documented public compatibility fixes.
No full graph rerun was needed for these presentation changes.

Fresh reading settings use 20. Existing reading preferences are preserved.
The VN compatibility notice is removed. No VN save interoperability was added.
The two special magic values use original v_b3_ch11_magic, with no upgrade controls.

Android 16 review: existing inset handling retained; documented predictive Back
opt-out preserves legacy callback behaviour. Reverse portrait is explicitly
sensorPortrait. Native code is unchanged. Actual device update, system Back and
appearance checks remain pending; jsdom cannot verify Android or render a screen.

Flori previously accepted the Full immersion countdown on the phone, including
Next/Continue/Back behaviour. That module remains unchanged in this build.
No Google Play upload, private Site deployment or Google Drive archive occurred.

Signed AAB validated with bundletool and JAR verification. A Play-derived universal APK is signed by the original key and its game assets/DEX match the direct APK. See tests/play-package-report.json and PLAY-PREPARATION.md.
