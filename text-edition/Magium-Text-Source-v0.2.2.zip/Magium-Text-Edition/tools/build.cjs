const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'..'),src=path.join(root,'src'),vendor=path.join(root,'vendor/thuiop');
const parser=require(vendor+'/src/parser');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
(async()=>{
 const data={};for(const n of fs.readdirSync(vendor+'/data/en').filter(n=>n.endsWith('.magium')))Object.assign(data,await parser.parse(vendor+'/data/en/'+n));
 const patches=JSON.parse(fs.readFileSync(root+'/editorial-patches.json'));
 for(const [id,paragraphs]of Object.entries(patches))data[id].paragraphs=paragraphs;
 fs.writeFileSync(src+'/data.js','const ORIGINAL_SCENES='+JSON.stringify(data)+';\n');
 const locale=JSON.parse(fs.readFileSync(vendor+'/data/en/ui.json'));
 const files=['src/parser.js','src/utils.js','src/renderers.js','public/scripts/utils.js','public/scripts/stats.js','templates/main.ejs'];
 const manifest={commit:'51f5aa9406c094e5133be2c7d69988296f86cfbc',repository:'https://github.com/thuiop/magium-dev',files:Object.fromEntries(files.map(n=>[n,hash(fs.readFileSync(vendor+'/'+n))])),sceneCount:Object.keys(data).length};
 fs.writeFileSync(root+'/upstream-integrity.json',JSON.stringify(manifest,null,2));
 const utils=fs.readFileSync(vendor+'/src/utils.js','utf8'),renderers=fs.readFileSync(vendor+'/src/renderers.js','utf8'),client=fs.readFileSync(vendor+'/public/scripts/utils.js','utf8'),statsClient=fs.readFileSync(vendor+'/public/scripts/stats.js','utf8');
 const runtime=`/* Generated wrappers. Vendored upstream bodies below are byte-for-byte unchanged. */
(function(root){
const node=typeof module!=='undefined'&&module.exports, ejs=root.ejs||(node?require('ejs'):null);
const locale=${JSON.stringify(locale)};
const engineEjs=Object.assign({},ejs,{renderFile:(_path,locals)=>locals});
function utilsModule(require,module,exports){
${utils}
}
const u={exports:{}};utilsModule(()=>engineEjs,u,u.exports);
function rendererModule(require,module,exports,process){
${renderers}
}
const r={exports:{}};rendererModule(name=>name==='ejs'?engineEjs:name==='./utils.js'?u.exports:name==='path'?{join:(...p)=>p.join('/')}:name==='fs'?{existsSync:()=>false}:null,r,r.exports,{cwd:()=>'',resourcesPath:null});
function storageBridge(initial={}){
 const copy=x=>JSON.parse(JSON.stringify(x));let stores={currentState:copy(initial.currentState||{}),achievements:copy(initial.achievements||{})};
 const readSaveFromLocalStorage=id=>copy(stores[id]||{}),writeSaveToLocalStorage=(id,value)=>{stores[id]=copy(value)};
 let locals,statElements={};const window={scroll(){},location:{pathname:'/stats',reload(){}}},document={addEventListener(){},getElementById:id=>statElements[id]||null};
${client}
${statsClient}
 // Compatibility shim: the consolation variable is a counter, not an awarded badge.
 const upstreamStoreVariable=storeVariable;
 storeVariable=function(key,value){if(key==='v_ac_b3_ch9_consolation')return storeItem(key,value,'achievements');return upstreamStoreVariable(key,value);};
 return {storeVariable,setResponseVariables,read:()=>copy(stores),replace:value=>{stores=copy(value)},initializeStats:()=>initStats(),confirmAllocation:values=>{initStats();statElements={};for(const [key,value]of Object.entries({...stores.currentState,...values}))if(key.startsWith('v_'))statElements[key.slice(2)+'_value']={innerHTML:String(value)};confirmStats();statElements={};}};
}
function renderer(data){const requestData=Object.assign({},data,locale);return (body,sceneOverride)=>r.exports.renderScene({body,data:sceneOverride?Object.assign({},requestData,{[body.v_current_scene]:sceneOverride}):requestData});}
const api={renderer,storageBridge,conditions:u.exports.apply_conditions,locale};if(node)module.exports=api;else root.MagiumOriginal=api;
})(typeof globalThis!=='undefined'?globalThis:this);\n`;
 fs.writeFileSync(src+'/original-runtime.js',runtime);
 const html=fs.readFileSync(src+'/index.html','utf8').replace('<link rel="stylesheet" href="style.css">','<style>'+fs.readFileSync(src+'/style.css','utf8')+'</style>').replace(/<script src="([^"]+)"><\/script>/g,(_,name)=>'<script>'+fs.readFileSync(src+'/'+name,'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
 fs.mkdirSync(root+'/dist',{recursive:true});fs.writeFileSync(root+'/dist/Magium-Text-Edition-v0.2.2.html',html);
 console.log(JSON.stringify({scenes:Object.keys(data).length,editorialPatches:Object.keys(patches),htmlBytes:Buffer.byteLength(html)}));
})().catch(e=>{console.error(e);process.exit(1)});
