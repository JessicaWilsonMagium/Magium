const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto'),vm=require('vm'),cp=require('child_process');
const {JSDOM,ResourceLoader,VirtualConsole}=require('jsdom');
const root=path.resolve(__dirname,'..'),apk=root+'/dist/Magium-Text-Edition-v0.2.2.apk',assets=root+'/build/qa/assets';
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
cp.execFileSync('python3',['-c',`import zipfile,pathlib,json,hashlib
r=pathlib.Path(${JSON.stringify(root)})
with zipfile.ZipFile(r/'dist/Magium-Text-Edition-v0.2.2.apk') as z:
 names=z.namelist();assert len(names)==len(set(names))
 for n in names:
  if n.startswith('assets/'):z.extract(n,r/'build/qa')
 assert z.read('classes.dex')==(r/'android/classes.dex').read_bytes()
 assert len([n for n in names if n.endswith('/data.js')])==1
 assert not any(n.lower().endswith(('.mp3','.ogg','.wav','.webp','.jpg')) for n in names)
 assert [n for n in names if n.lower().endswith('.png')]==['res/drawable/ic_magium.png']
 from PIL import Image
 import io
 packaged=Image.open(io.BytesIO(z.read('res/drawable/ic_magium.png'))).convert('RGBA')
 original=Image.open(r/'android/res/drawable/ic_magium.png').convert('RGBA')
 assert packaged.size==original.size and packaged.tobytes()==original.tobytes()
 assert z.read('assets/index.html').count(b'data:image/png;base64,')==1
 import base64,re
 logo=re.search(rb'data:image/png;base64,([^\"]+)',z.read('assets/index.html')).group(1)
 assert base64.b64decode(logo)==(r/'android/res/drawable/ic_magium.png').read_bytes()
 assert b'VN backups from' not in z.read('assets/index.html')
 for t in [b'text/html',b'application/javascript',b'text/css',b'application/json']:
  assert t in z.read('classes.dex')
 print(json.dumps({'entries':len(names),'assets':len([n for n in names if n.startswith('assets/')]),'dexSha256':hashlib.sha256(z.read('classes.dex')).hexdigest()}))
`],{encoding:'utf8'});
const integrity=JSON.parse(fs.readFileSync(root+'/upstream-integrity.json'));for(const [n,h]of Object.entries(integrity.files)){const bytes=fs.readFileSync(root+'/vendor/thuiop/'+n);assert.equal(hash(bytes),h);if(['src/utils.js','src/renderers.js','public/scripts/utils.js','public/scripts/stats.js'].includes(n))assert(fs.readFileSync(assets+'/original-runtime.js','utf8').includes(bytes.toString()));}
let requests=[];class OfflineAssets extends ResourceLoader{fetch(url){requests.push(url);const match=/^https:\/\/appassets\.androidplatform\.net\/assets\/([A-Za-z0-9_.-]+)$/.exec(url);if(!match)throw Error('Unexpected network request '+url);return Promise.resolve(fs.readFileSync(assets+'/'+match[1]));}}
const origin='https://appassets.androidplatform.net/assets/index.html';
async function boot(initial={}){const errors=[],vc=new VirtualConsole;vc.on('jsdomError',e=>errors.push(e.message));const dom=new JSDOM(fs.readFileSync(assets+'/index.html','utf8'),{url:origin,resources:new OfflineAssets,runScripts:'dangerously',virtualConsole:vc,beforeParse(w){w.TextEncoder=TextEncoder;w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');this.dispatchEvent(new w.Event('close'))};for(const[k,v]of Object.entries(initial))w.localStorage.setItem(k,v);}});await new Promise((resolve,reject)=>{dom.window.addEventListener('load',resolve,{once:true});setTimeout(()=>reject(Error('Offline startup timeout')),10000).unref()});assert.deepEqual(errors,[]);assert(dom.window.MagiumText);return dom;}
(async()=>{const sentinel='magium-text-upstream-lab-v1-auto';let dom=await boot({[sentinel]:'STABLE UNTOUCHED'}),w=dom.window,d=w.document;d.getElementById('startButton').click();d.getElementById('confirmAction').click();assert(!d.getElementById('game').hidden);while(!d.getElementById('nextButton').disabled)d.getElementById('nextButton').click();assert.equal(d.getElementById('nextButton').textContent,'Choose above');assert(d.querySelectorAll('#choices button').length>1);d.querySelector('#choices button').click();w.MagiumText.model.saveSlot(1,'APK roundtrip');let exported;w.MagiumTextFiles={save:(name,text)=>{exported={name,text}},open(){}};d.getElementById('backupButton').click();d.getElementById('exportBackup').click();assert(exported.name.startsWith('Magium-Text-Backup-'));w.MagiumText.receiveBackup(exported.text);assert(d.getElementById('confirmImport').hidden===false);assert.equal(w.localStorage.getItem(sentinel),'STABLE UNTOUCHED');const before=JSON.parse(JSON.stringify(w.MagiumText.model.snapshot())),stored=Object.fromEntries(Object.keys(w.localStorage).map(k=>[k,w.localStorage.getItem(k)]));dom.window.close();dom=await boot(stored);w=dom.window;d=w.document;d.getElementById('continueButton').click();assert.deepEqual(JSON.parse(JSON.stringify(w.MagiumText.model.snapshot())),before);assert.equal(w.localStorage.getItem(sentinel),'STABLE UNTOUCHED');d.getElementById('statsButton').click();assert(d.getElementById('statsDialog').open);assert(d.querySelectorAll('.statCard').length>=9);assert.equal(d.querySelector('.lab-banner'),null);assert.equal(d.getElementById('testingDialog'),null);assert(!fs.existsSync(assets+'/test-fixtures.js'));assert(!fs.existsSync(assets+'/testing.js'));dom.window.close();
const report={apkBytes:fs.statSync(apk).size,apkSha256:hash(fs.readFileSync(apk)),offlineStartup:'passed in jsdom at exact native origin',networkRequests:requests.length,allRequestsBundled:true,assetAndDexIntegrity:'passed',originalRuntimeSourceHashes:'passed',saveReloadAndNativeBridgeCalls:'passed in jsdom with mocked native document picker',physicalAndroidExecution:'not available; user acceptance pending',savedOrigin:origin,experimentalStorageSentinelUnchanged:true};fs.writeFileSync(root+'/tests/artifact-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));})().catch(e=>{console.error(e);process.exit(1)});
