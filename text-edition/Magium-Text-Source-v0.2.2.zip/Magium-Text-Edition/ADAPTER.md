# Magium Text Edition 0.2.1 — runtime and save contract

The public edition retains Thuiop's original parser, conditions, scene renderer,
frontend variable helpers and stat routines. The exact sources remain unedited in
vendor/thuiop at commit 51f5aa9406c094e5133be2c7d69988296f86cfbc.
Their SHA-256 hashes are recorded in upstream-integrity.json. Build wrappers adapt
server output to the offline reader without requiring Express, Electron or HTMX.

## Two deliberate compatibility corrections

1. In Ch3-Clobber and Ch3-Clobber2 only, clear v_is_dead before scene rendering.
A failed initial moving-crossbow tactic can leave this scratch flag at 1 while
Barry is still alive and switches to throwing trees. The flag otherwise blocks
the successful leader continuation. Legacy snapshots in these two scenes are
repaired too. Actual failed/death scenes keep their original outcomes.
2. Exempt v_ac_b3_ch9_consolation from the frontend achievement guard. This variable
is an incrementing counter, not a badge; treating value 2 as already awarded
prevents it ever reaching 5. The wrapper invokes the original storeItem for this
counter and the original storeVariable for all other variables. Prize badges
remain guarded against duplicate awards. Both corrections were already in the
previous independent text engine; neither adds a story event or rewrites prose.

The original function bodies and story source files are preserved. These are
explicit adapter corrections, not a claim of byte-for-byte original behaviour.
The differential report compares the original reference plus these two corrections.

## Reading, stats and Back

All 34 chapters and 2,159 records are included. Six editorial paragraph patches
retain the existing formatting and closing notices; no assignments, choice
conditions, destinations or achievement declarations are changed in story data.
The final community link is Reddit only, as requested.

New snapshots retain raw value types and the incoming render state. Restoring
one rebuilds its view without reapplying assignments or rewards. Back restores
full run state across pages and Continue actions, stopping at genuine choices.
Collected achievement discoveries remain cumulative. History is session-only,
limited to 200 entries / 2 MiB, and is not exported in backups.

Explicit story choices opening Stats defer target entry until the dialog closes
or confirms. Ordinary toolbar Stats uses the original initializer and confirmer,
then refreshes stat-dependent non-additive outcomes without replaying entry resets
or additive rewards. This reward-preserving policy belongs to our adapter.
On the title screen the Stats button is disabled and shows no point count until
a run is resumed or loaded, fixing the zero-value display found in phone tests.

## Production identity and existing saves

Android package: org.magium.textedition. Version: 0.2.1, versionCode 4.
Signer: the same original certificate. Native DEX is reused unchanged from the
verified text APK 0.1.3. WebView origin and local storage keys are unchanged:
https://appassets.androidplatform.net/assets/index.html and magium-text-edition-v1.
Existing normal autosaves, 30 named slots, checkpoints, book starts, achievements
and reading preferences therefore remain under the same identity.

Legacy saves preserve their post-entry story variables, stats, points, awards and
reading offset. They lack the original pre-entry render input, so the adapter
reconstructs their visible view without replaying rewards. Identical visible text
for every possible legacy save cannot be proven, particularly transient assignments.
The two-scene stale-flag repair is the intentional exception to exact flag preservation.
The backup format remains version 1; compact JSON keeps enlarged snapshots within
the existing native 2 MiB limit. Imports validate before transactional writes.

No testing interface, stat editor, chapter selector or prepared-route files are
packaged in this public build. Normal Back stops at genuine choices. The future
25-achievement settings remain disabled, so all included books are unlocked.

## Private experimental app

Magium Engine Test remains a separate app, org.magium.textupstreamlab, with its own
saves and testing controls. This release does not update it or the private website.
A copy of an experimental normal-run backup can be imported into the public text
edition; earlier counter behaviour is corrected for subsequent increments.
The title-screen bug remains in the already-installed experimental build only.

## Verification boundary

The scene comparisons are synthetic state and transition tests, not all possible
histories. Actual APK assets are booted in jsdom at the native origin; this does
not execute Android or render the screen. Native DEX, MIME strings, certificate,
manifest, assets and save-storage identity are checked. Flori physically tested
import, save/reopen, Continue Back, stat refund, portrait flip, offline reopening,
Android export/import of distinct slots and private choice replay in the preceding
experimental build. The final production APK has not itself been run on a device.

## Full immersion display restored in 0.2.1

A new presentation-only temporary-stats.js draws the temporary numbers only for
Ch6-Eiden-vs-dragon with v_maximized_stats_used=1. Values begin at 10 and fall every
1.5 seconds, never below the player's actual values. The available-points label
uses the same temporary display. Real engine values and serialized saves are
never replaced with those displayed values. Upgrade controls are disabled during
the countdown; closing, cancelling or changing scenes stops it. Delayed background
timers settle according to elapsed time. Reopening starts one fresh display.
The existing Full immersion award trigger and cumulative collection are unchanged.
Core story, engine, model, backup, rewind and achievement files have the exact
same hashes as 0.2.0. Nine additional regressions exercise the visual boundary.
