/* Independent reference: real upstream EJS templates + original browser script in VM.
 * Adapter uses a different browser wrapper and output layer. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),vendor=root+'/vendor/thuiop';process.chdir(vendor);
const E=require(root+'/src/engine'),ejs=require('ejs'),reference=require(vendor+'/src/renderers');
const D=JSON.parse(JSON.stringify(vm.runInNewContext(fs.readFileSync(root+'/src/data.js','utf8')+';ORIGINAL_SCENES'))),locale=JSON.parse(fs.readFileSync(vendor+'/data/en/ui.json'));
const clone=x=>JSON.parse(JSON.stringify(x));let captured;
const realRender=ejs.renderFile;ejs.renderFile=function(file,locals){captured=locals;return realRender(file,locals,{cache:true})};
let stores;const client={window:{scroll(){}},readSaveFromLocalStorage:k=>clone(stores[k]||{}),writeSaveToLocalStorage:(k,v)=>{stores[k]=clone(v)}};vm.createContext(client);vm.runInContext(fs.readFileSync(vendor+'/public/scripts/utils.js','utf8'),client);
vm.runInContext("const originalStore=storeVariable;storeVariable=(k,v)=>k==='v_ac_b3_ch9_consolation'?storeItem(k,v,'achievements'):originalStore(k,v)",client);
const requestData={...D,...locale};
async function referenceEnter(id,input){stores=clone(input);stores.currentState.v_current_scene=id;if(/^Ch3-Clobber2?$/.test(id))stores.currentState.v_is_dead='0';const html=await reference.renderScene({body:{...stores.currentState,...stores.achievements},data:requestData});for(const [,code]of html.matchAll(/<script>(.*?)<\/script>/gs))vm.runInContext(code,client);return {scene:clone(captured.scene),stores:clone(stores)};}
const statKeys=E.stats.map(([k])=>'v_'+k);
function seed(n){const values={v_available_points:'12',v_max_stat:'4'};for(const k of statKeys)values[k]=String(Math.min(n,4));return {currentState:values,achievements:{}};}
function body(input){return {...input.currentState,...input.achievements};}
function check(e,r,id){const s=e.snapshot(),v=e.view();assert.deepEqual(s.upstream.current,r.stores.currentState,id+' current state');assert.deepEqual(s.upstream.awards,r.stores.achievements,id+' raw achievements');assert.deepEqual(v.paragraphs,r.scene.paragraphs,id+' paragraphs');assert.deepEqual(v.choices,r.scene.choices,id+' choices');assert.deepEqual(v.checks,r.scene.statChecks.map(x=>({stat:E.stats.find(([,name])=>name===x.variable)?.[0]||x.variable,required:x.value,pass:!!x.success})),id+' checks');}
(async()=>{
 let cases=0,edges=0,roundTrips=0;const faults=[];let sources=0;
 for(const scene of Object.values(D)){
  // Baselines plus every condition group satisfied exactly, and each threshold's neighbours.
  const variants=[seed(0),seed(1),seed(2),seed(3),seed(4)];
  const groups=[...scene.setVariables,...scene.paragraphs,...scene.choices].flatMap(x=>x.conditions||[]);
  const seen=new Set();for(const group of groups){const input=seed(0);for(const atom of group){const m=/^(\w+) (>=|<=|==|!=|>|<) (\d+)$/.exec(atom);if(!m)continue;const n=Number(m[3]),value=m[2]==='>'?n+1:m[2]==='<'?Math.max(0,n-1):m[2]==='!='?n+1:n;(m[1].startsWith('v_ac_')?input.achievements:input.currentState)[m[1]]=String(value);}const k=JSON.stringify(input);if(!seen.has(k)){variants.push(input);seen.add(k);}}
  for(const input of variants){
   const r=await referenceEnter(scene.id,input),e=E.create(D,{id:scene.id,stores:input});check(e,r,scene.id);cases++;
   // Full snapshot round-trip must not re-run rewards, reset stats or change cached text.
   const saved=e.snapshot(),view=e.view();if(E.stats.every(([k])=>Number.isInteger(saved.vars['v_'+k])&&saved.vars['v_'+k]>=0&&saved.vars['v_'+k]<=saved.vars.v_max_stat)&&saved.vars.v_available_points>=0){try{e.restore(saved)}catch(error){throw Error(scene.id+': '+error.message)}assert.deepEqual(e.snapshot(),saved);assert.deepEqual(e.view(),view);roundTrips++;}
   // One outgoing edge per case; actual reference setResponseVariables + EJS entry.
   const c=r.scene.choices.find(c=>!c.special&&D[c.target]);if(c){const i=r.scene.choices.indexOf(c);client.response=c;vm.runInContext('setResponseVariables(response)',client);const next=await referenceEnter(c.target,stores);e.choose(i);check(e,next,scene.id+' -> '+c.target);edges++;}
  }
  sources++;if(sources%300===0)console.log('Compared',sources,'scenes;',cases,'entry states;',edges,'transitions');
 }
 const corrections=['Chapter 3 Clobber scratch flag reset','Consolation counter exempted from achievement guard'];
 const report={upstreamCommit:'51f5aa9406c094e5133be2c7d69988296f86cfbc',scenes:sources,entryCases:cases,normalTransitions:edges,snapshotRoundTrips:roundTrips,scope:'Original renderer/state helpers plus the two documented compatibility corrections. All records; five stat baselines and condition-group witnesses. Not exhaustive combinations or all possible playthroughs. Snapshot validation skips synthetic inputs with impossible stat values.',mismatches:0,documentedReferenceCorrections:corrections};fs.writeFileSync(root+'/tests/differential-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
