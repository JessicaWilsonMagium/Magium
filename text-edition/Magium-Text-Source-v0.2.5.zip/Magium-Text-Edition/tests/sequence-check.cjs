/* Independent reference: real upstream EJS templates + original browser script in VM.
 * Adapter uses a different browser wrapper and output layer. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),vendor=root+'/vendor/thuiop';process.chdir(vendor);
const E=require(root+'/src/engine'),ejs=require('ejs'),reference=require(vendor+'/src/renderers');
const D=JSON.parse(JSON.stringify(vm.runInNewContext(fs.readFileSync(root+'/src/data.js','utf8')+';ORIGINAL_SCENES'))),locale=JSON.parse(fs.readFileSync(vendor+'/data/en/ui.json'));
const clone=x=>JSON.parse(JSON.stringify(x));let captured;
const realRender=ejs.renderFile;ejs.renderFile=function(file,locals){captured=locals;return realRender(file,locals,{cache:true})};
let stores;const client={window:{scroll(){}},readSaveFromLocalStorage:k=>clone(stores[k]||{}),writeSaveToLocalStorage:(k,v)=>{stores[k]=clone(v)}};vm.createContext(client);vm.runInContext(fs.readFileSync(vendor+'/public/scripts/utils.js','utf8'),client);
vm.runInContext("const originalStore=storeVariable;storeVariable=(k,v)=>k==='v_ac_b3_ch9_consolation'?storeItem(k,v,'achievements'):originalStore(k,v)",client);
const requestData={...D,...locale};
async function referenceEnter(id,input){stores=clone(input);stores.currentState.v_current_scene=id;if(/^Ch3-Clobber2?$/.test(id))stores.currentState.v_is_dead='0';const html=await reference.renderScene({body:{...stores.currentState,...stores.achievements},data:requestData});for(const [,code]of html.matchAll(/<script>(.*?)<\/script>/gs))vm.runInContext(code,client);return {scene:clone(captured.scene),stores:clone(stores)};}
const statKeys=E.stats.map(([k])=>'v_'+k);
function seed(n){const values={v_available_points:'12',v_max_stat:'4'};for(const k of statKeys)values[k]=String(Math.min(n,4));return {currentState:values,achievements:{}};}
function body(input){return {...input.currentState,...input.achievements};}
function check(e,r,id){const s=e.snapshot(),v=e.view();assert.deepEqual(s.upstream.current,r.stores.currentState,id+' current state');assert.deepEqual(s.upstream.awards,r.stores.achievements,id+' raw achievements');assert.deepEqual(v.paragraphs,r.scene.paragraphs,id+' paragraphs');assert.deepEqual(v.choices,r.scene.choices,id+' choices');assert.deepEqual(v.checks,r.scene.statChecks.map(x=>({stat:E.stats.find(([,name])=>name===x.variable)?.[0]||x.variable,required:x.value,pass:!!x.success})),id+' checks');}

(async()=>{
 const fixtures=clone(vm.runInNewContext(fs.readFileSync(root+'/tests/legacy-fixtures.js','utf8')+';MAGIUM_TEST_FIXTURES'));
 let transitions=0,runs=0,restores=0;const reached=new Set();let rng=1701026;const rand=n=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng%n};
 for(const fixture of Object.values(fixtures))for(let run=0;run<8;run++){
  const saved=clone(fixture),e=E.create(D);e.restore(saved);let stores0={currentState:{},achievements:{}};
  for(const [k,v]of Object.entries(saved.vars))(k.startsWith('v_ac_')?stores0.achievements:stores0.currentState)[k]=String(v);
  // Fixture is a saved post-entry state. Use the renderer for choices, without replaying its entry assignments.
  await referenceEnter(saved.id,stores0);stores=clone(stores0);runs++;
  for(let step=0;step<150;step++){
   reached.add(e.snapshot().id);const choices=e.view().choices,available=choices.map((c,i)=>({c,i})).filter(x=>!x.c.special&&D[x.c.target]);if(!available.length)break;
   const {c,i}=available[rand(available.length)];client.response=c;vm.runInContext('setResponseVariables(response)',client);const r=await referenceEnter(c.target,stores);e.choose(i);check(e,r,'sequence '+runs+' step '+step);transitions++;
   if(step%7===0){const before=e.snapshot(),v=e.view();e.restore(JSON.parse(JSON.stringify(before)));assert.deepEqual(e.snapshot(),before);assert.deepEqual(e.view(),v);restores++;}
  }
 }
 const report={runs,transitions,restores,distinctScenes:reached.size,mismatches:0,scope:'Eight seeded continuation runs from each of 34 saved chapter starts, at most 150 transitions each. Original renderer and browser state helpers as reference, with the two existing adapter adjustments aligned. No rendered browser or physical Android execution; not every possible history.'};
 fs.writeFileSync(root+'/tests/sequence-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
