const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),version=require('../package.json').version;
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.MAGIUM_BROWSER_PATH,headless:true,args:['--no-sandbox']});
 const results=[];
 try{for(const width of [320,390,736])for(const theme of ['paper','dark','night']){
  const page=await browser.newPage({viewport:{width,height:900}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.route('https://appassets.androidplatform.net/assets/index.html',r=>r.fulfill({path:root+'/dist/Magium-Text-Edition-v'+version+'.html',contentType:'text/html'}));
  await page.addInitScript(theme=>{
   localStorage.setItem('magium-text-edition-v1-reading',JSON.stringify({size:20,theme,font:'serif'}));
   localStorage.setItem('magium-text-edition-v1-achievements',JSON.stringify({version:1,earned:['v_ac_ch5_deed','v_ac_ch5_shameless']}));
  },theme);
  await page.goto('https://appassets.androidplatform.net/assets/index.html');
  const before=await page.evaluate(()=>({state:JSON.stringify(MagiumText.model.snapshot()),storage:JSON.stringify({...localStorage})}));
  await page.locator('#titleAchievements').click();
  assert.equal(await page.locator('.achievementMenu button').count(),3);
  assert.equal(await page.locator('.achievementCard').count(),0);
  if(width===390&&theme==='paper')await page.screenshot({path:root+'/tests/achievement-books.png'});
  const seen=new Set();
  for(let book=1;book<=3;book++){
   await page.locator('.achievementMenu button').nth(book-1).click();
   const text=await page.locator('#accessProgress').textContent();
   if(book<3){assert(text.includes('25 achievements'));assert(text.includes('All books are unlocked during testing.'));}else{assert(!text.includes('Book 4'));}
   assert(!(await page.locator('#achievementsDialog').textContent()).match(/leaderboard|paid to unlock|Google achievements/i));
   if(width===390&&theme==='paper'&&book===1)await page.screenshot({path:root+'/tests/achievement-chapters.png'});
   const count=await page.locator('.achievementMenu button').count();
   for(let i=0;i<count;i++){
    await page.locator('.achievementMenu button').nth(i).click();
    const cards=page.locator('.achievementCard');assert((await cards.count())>0);assert((await cards.count())<=5);
    for(const id of await cards.evaluateAll(nodes=>nodes.map(n=>n.dataset.achievement))){assert(!seen.has(id),'Duplicate award '+id);seen.add(id);}
    const clipped=await page.evaluate(()=>{const d=document.getElementById('achievementsDialog');return d.scrollWidth>d.clientWidth+1||[...d.querySelectorAll('.achievementCard')].some(c=>{const r=c.getBoundingClientRect();return [...c.querySelectorAll('strong,p')].some(n=>{const t=n.getBoundingClientRect();return t.left<r.left||t.right>r.right;});});});assert.equal(clipped,false);
    if(width===390&&book===1&&i===4)await page.screenshot({path:root+'/tests/achievement-'+theme+'.png'});
    // Native Android Back must return to the chapter menu, preserving the dialog.
    assert.equal(await page.evaluate(()=>MagiumText.backPressed()),true);
    assert.equal(await page.locator('#achievementsDialog').getAttribute('open'),'');
    assert.equal(await page.locator('.achievementMenu button').count(),count);
   }
   await page.locator('#achievementBack').click();assert.equal(await page.locator('.achievementMenu button').count(),3);
  }
  assert.equal(seen.size,136);
  assert.deepEqual(await page.evaluate(()=>({state:JSON.stringify(MagiumText.model.snapshot()),storage:JSON.stringify({...localStorage})})),before);
  // Escape follows the same hierarchy; the close control remains available.
  await page.locator('.achievementMenu button').first().click();await page.keyboard.press('Escape');assert.equal(await page.locator('.achievementMenu button').count(),3);
  await page.evaluate(()=>MagiumText.backPressed());assert.equal(await page.locator('#achievementsDialog').getAttribute('open'),null);
  assert.deepEqual(errors,[]);results.push({width,theme,awards:seen.size,passed:true});await page.close();
 }}finally{await browser.close();}
 fs.writeFileSync(root+'/tests/achievement-browser-report.json',JSON.stringify({version,results,physicalAndroid:false},null,2));
 console.log('All 136 achievements reachable exactly once per theme/width; max five cards per page; Back, Escape, targets and unchanged saves verified.');
})().catch(e=>{console.error(e);process.exit(1)});
