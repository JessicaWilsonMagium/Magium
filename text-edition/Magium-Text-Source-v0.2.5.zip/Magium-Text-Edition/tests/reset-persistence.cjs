const assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),E=require('../src/engine'),M=require('../src/model'),B=require('../src/backup');
const D=vm.runInNewContext(fs.readFileSync(__dirname+'/../src/data.js','utf8')+';ORIGINAL_SCENES'),F=vm.runInNewContext(fs.readFileSync(__dirname+'/legacy-fixtures.js','utf8')+';MAGIUM_TEST_FIXTURES');const clone=x=>JSON.parse(JSON.stringify(x));
class Storage{constructor(){this.m=new Map}getItem(k){return this.m.get(k)??null}setItem(k,v){this.m.set(k,String(v))}removeItem(k){this.m.delete(k)}}
for(const unlock of [0,1,2]){
 const st=new Storage,m=M.create(D,st),s=clone(F['B3-Ch04a-Intro']);s.id='B3-Ch04a-Introduction';s.vars.v_current_scene=s.id;s.vars.v_b3_ch1_unlock=unlock;s.vars.v_b3_ch3_stats_unavailable=1;s.vars.v_available_points=7;s.page=0;s.readingPosition={id:s.id,offset:0};delete s.upstream;
 for(const[k]of E.stats)s.vars['v_'+k]=E.stats.slice(0,9).some(([x])=>x===k)?2:0;
 m.jump(s);m.saveSlot(1,'before reset');const idx=m.engine.view().choices.findIndex(x=>x.target==='B3-Ch04a-Introduction2');m.choose(idx);const points=unlock===2?26:25;assert.equal(m.snapshot().vars.v_available_points,points);for(const[k]of E.stats)assert.equal(m.snapshot().vars['v_'+k],0);
 m.saveSlot(2,'after reset');assert(m.back());assert.equal(m.snapshot().vars.v_strength,2);assert.equal(m.snapshot().vars.v_available_points,7);m.choose(idx);assert.equal(m.snapshot().vars.v_available_points,points);
 m.invest({strength:2,magical_sense:3});m.saveSlot(3,'reallocated');const fresh=M.create(D,st);fresh.load('-auto');assert.equal(fresh.snapshot().vars.v_available_points,points-5);assert.equal(fresh.snapshot().vars.v_magical_sense,3);
 const validator=E.create(D),validate=x=>validator.restore(x),exported=B.create(st,validate,34),dest=new Storage;B.restore(dest,B.parse(exported,validate),validate);const imported=M.create(D,dest);
 for(const [slot,p,str]of [[1,7,2],[2,points,0],[3,points-5,2]]){imported.load('-slot-'+slot);assert.equal(imported.snapshot().vars.v_available_points,p);assert.equal(imported.snapshot().vars.v_strength,str)}
 console.log('PASS reset branch '+unlock+': before/after slots, Back and repeat, reinvestment, cold resume, JSON export/import');
}
