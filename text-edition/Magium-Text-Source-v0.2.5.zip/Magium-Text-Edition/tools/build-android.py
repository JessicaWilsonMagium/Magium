#!/usr/bin/env python3
"""Package web sources with the unmodified native DEX from Text Edition 0.1.3.
No signing material is included. Use the original private signing key.
Requires Android build-tools 36.0.0 and platform 36; Java 17 for apksigner.
"""
import argparse,os,pathlib,subprocess,shutil,zipfile,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--build-tools',required=True);p.add_argument('--android-jar',required=True);p.add_argument('--keystore',required=True);p.add_argument('--bundletool',help='Optional official bundletool JAR: also build a signed Play AAB');a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent.parent;bt=pathlib.Path(a.build_tools).resolve();jar=pathlib.Path(a.android_jar).resolve();build=root/'build/android';dist=root/'dist';dist.mkdir(exist_ok=True)
if build.exists():shutil.rmtree(build)
(build/'assets').mkdir(parents=True)
html=(root/'src/index.html').read_text()
import re
names=['index.html','style.css']+re.findall(r'<script src="([^"]+)"',html)
assert len(names)==len(set(names))
for name in names:shutil.copy2(root/'src'/name,build/'assets'/name)
for name in ['LICENSE','CREDITS.md','ATTRIBUTION.txt','ADAPTER.md','upstream-integrity.json']:
 shutil.copy2(root/name,build/'assets'/name)
shutil.copy2(root/'vendor/EJS-LICENSE',build/'assets/EJS-LICENSE.txt')
env=dict(os.environ);env['LD_LIBRARY_PATH']=str(bt/'lib64')+':'+env.get('LD_LIBRARY_PATH','')
run=lambda *args,**kwargs:subprocess.run([str(x) for x in args],check=True,env=env,**kwargs)
raw=build/'raw.apk';aligned=build/'aligned.apk';apk=dist/'Magium-Text-Edition-v0.2.5.apk'
run(bt/'aapt','package','-f','-M',root/'android/AndroidManifest.xml','-I',jar,'-S',root/'android/res','-A',build/'assets','-F',raw)
with zipfile.ZipFile(raw,'a',compression=zipfile.ZIP_DEFLATED) as z:z.write(root/'android/classes.dex','classes.dex')
run(bt/'zipalign','-f','4',raw,aligned)
run(bt/'apksigner','sign','--ks',pathlib.Path(a.keystore).resolve(),'--ks-key-alias',os.environ.get('MAGIUM_KEY_ALIAS','magium-test'),'--ks-pass','env:MAGIUM_STORE_PASS','--key-pass','env:MAGIUM_KEY_PASS','--out',apk,aligned)
verified=run(bt/'apksigner','verify','--verbose','--print-certs',apk,capture_output=True,text=True).stdout
(root/'tests/android-signature.txt').write_text(verified)
assert '680be316ed06267666f44298fe7d3064db823cff0227f352e7502e1b4c8c10aa' in verified
print(json.dumps({'apk':str(apk),'bytes':apk.stat().st_size,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'originalSignerVerified':True}))

if a.bundletool:
 # Convert resources to the protobuf form required by Android App Bundles.
 proto=build/'proto.apk';module=build/'base.zip';bundle=apk.with_suffix('.aab')
 run(bt/'aapt2','convert','--output-format','proto','-o',proto,raw)
 with zipfile.ZipFile(proto) as source,zipfile.ZipFile(module,'w',compression=zipfile.ZIP_DEFLATED) as target:
  for name in source.namelist():
   if name.startswith('META-INF/') or name.endswith('/'):continue
   dest='manifest/AndroidManifest.xml' if name=='AndroidManifest.xml' else 'dex/classes.dex' if name=='classes.dex' else name
   target.writestr(dest,source.read(name))
 if bundle.exists():bundle.unlink()
 run('java','-jar',pathlib.Path(a.bundletool).resolve(),'build-bundle','--modules='+str(module),'--output='+str(bundle))
 signer=['jarsigner'] if shutil.which('jarsigner') else ['java','-m','jdk.jartool/sun.security.tools.jarsigner.Main']
 run(*signer,'-keystore',pathlib.Path(a.keystore).resolve(),'-storepass:env','MAGIUM_STORE_PASS','-keypass:env','MAGIUM_KEY_PASS',bundle,os.environ.get('MAGIUM_KEY_ALIAS','magium-test'),capture_output=True,text=True)
 validation=run('java','-jar',pathlib.Path(a.bundletool).resolve(),'validate','--bundle='+str(bundle),capture_output=True,text=True).stdout
 (root/'tests/bundle-validation.txt').write_text(validation)
 print(json.dumps({'bundle':str(bundle),'bytes':bundle.stat().st_size,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bundletoolValidation':'passed'}))
