/* Shared player actions; artwork, audio and DOM are deliberately absent. */
(function(root){
 const node=typeof module!=='undefined'&&module.exports;
 const E=root.MagiumEngine||(node?require('./engine'):null),A=root.MagiumAchievements||(node?require('./achievements'):null),R=root.MagiumRewind||(node?require('./rewind'):null),Access=root.MagiumTextAccess||(node?require('./access'):null);
 const BASE='magium-text-edition-v1',clone=x=>JSON.parse(JSON.stringify(x));
 const prose=view=>view.paragraphs.map(p=>p.text.replaceAll('<br/>','\n').trim()).filter(Boolean).join('\n\n');
 function paginate(text,budget=1450){if(!text)return [''];const pages=[];for(let at=0;at<text.length;){let end=Math.min(at+budget,text.length);if(end<text.length){let split=text.lastIndexOf('\n\n',end);if(split<at+budget*.5)split=text.lastIndexOf(' ',end);if(split>at)end=split+1;}pages.push(text.slice(at,end));at=end;}return pages;}
 function create(data,storage,config={}){
  const test=false,key=BASE,engine=E.create(data),rewind=R.create();let started=false,pages=[''],pendingAwards=[];const intros=new Map();for(const id of Object.keys(data))if(/-Intro(?:1)?$/.test(id)){const p=E.location(id),k=p.book+':'+p.chapter;if(!intros.has(k))intros.set(k,id);}
  const read=s=>{try{return JSON.parse(storage.getItem(key+s))}catch{return null}},write=(s,v)=>storage.setItem(key+s,JSON.stringify(v));
  const collection=A.create(data,storage,key+'-achievements');for(const s of ['-auto','-checkpoint','-manual','-book2-start','-book3-start',...Array.from({length:30},(_,i)=>'-slot-'+(i+1))])collection.sync(read(s));
  function snapshot(){const s=engine.snapshot();s.readingPosition={id:s.id,offset:pages.slice(0,s.page).reduce((n,p)=>n+p.length,0)};return s;}
  function refresh(offset){const s=engine.snapshot(),view=engine.view();pages=paginate(prose(view));let p=s.page;if(Number.isFinite(offset)){let n=0;p=0;while(p+1<pages.length&&n+pages[p].length<=offset){n+=pages[p].length;p++;}}engine.page(Math.max(0,Math.min(p,pages.length-1)));const awards=collection.sync(engine.snapshot());for(const a of awards)if(!pendingAwards.some(x=>x.id===a.id))pendingAwards.push(a);return {state:engine.snapshot(),view:engine.view(),pages,awards};}
  function capture(){const s=snapshot(),p=E.location(s.id),intro=intros.get(p.book+':'+p.chapter);if(s.id===intro&&s.page===0){const starts=read('-chapter-starts')||{};if(!s.privateTestSetup||s.privateTestSetup.chapter!==intro){starts[intro]=s;write('-chapter-starts',starts);}if(p.book>1&&p.chapter===1&&!read('-book'+p.book+'-start'))write('-book'+p.book+'-start',s);}}
  function persist(){if(started){write('-auto',snapshot());capture();}}
  function record(){return {state:snapshot(),aux:Object.fromEntries(['-checkpoint','-book2-start','-book3-start'].map(s=>[s,storage.getItem(key+s)]))};}
  function restoreRecord(r){const before=record();engine.restore(r.state);try{for(const[s,v]of Object.entries(r.aux)){if(v===null)storage.removeItem(key+s);else storage.setItem(key+s,v)}}catch(e){engine.restore(before.state);for(const[s,v]of Object.entries(before.aux))try{if(v===null)storage.removeItem(key+s);else storage.setItem(key+s,v)}catch{}throw e}refresh(r.state.readingPosition?.offset);}
  function start(){engine.restart();rewind.clear();started=true;storage.removeItem(key+'-book2-start');storage.removeItem(key+'-book3-start');refresh(0);write('-checkpoint',snapshot());persist();}
  function load(suffix){const r=read(suffix),s=r?.state||r;if(!s)throw Error('No saved game here yet.');engine.restore(s);if(r?.bookStarts)for(const b of [2,3]){const bs=r.bookStarts[b];if(bs)write('-book'+b+'-start',bs);else storage.removeItem(key+'-book'+b+'-start');}else if(suffix!=='-auto')for(const b of [2,3])storage.removeItem(key+'-book'+b+'-start');rewind.clear();started=true;refresh(s.readingPosition?.id===s.id?s.readingPosition.offset:undefined);persist();}
  function jump(saved,{checkpoint=false}={}){engine.restore(saved);rewind.clear();started=true;refresh(saved.readingPosition?.offset||0);if(checkpoint)write('-checkpoint',snapshot());persist();}
  function step(){if(engine.snapshot().page>=pages.length-1)return false;rewind.push(record());engine.page(engine.snapshot().page+1);persist();return true;}
  function choose(index){const v=engine.view(),c=v.choices[index];if(!c)throw Error('This choice is unavailable.');if(c.target&&data[c.target]){const from=E.location(v.id).book,to=E.location(c.target).book;if(to>from&&from<=2){const gate=Access.status(collection.catalog,collection.snapshot().earned,from,!!config.achievementGates?.enabled);if(!gate.canContinue)return {blocked:gate};}}
   if(c.special==='saves')return {special:'saves'};if(c.special==='checkpoint_load'){load('-checkpoint');return {special:'loaded'}};
   const before=record(),continuation=R.isContinue(v),oldText=prose(v),result=engine.choose(index);if(continuation)rewind.push(before);else rewind.clear();
   refresh(result.special==='stats'&&prose(engine.view())===oldText?before.state.readingPosition.offset:0);if(result.special==='checkpoint_save')write('-checkpoint',snapshot());persist();return result;
  }
  function back(){const before=record(),r=rewind.pop();if(!r){if(engine.snapshot().page===0)return false;engine.page(engine.snapshot().page-1);persist();return true;}try{restoreRecord(r);persist();return true}catch(e){try{restoreRecord(before)}catch{}rewind.push(r);throw e;}}
  function invest(allocation){const before=record(),text=prose(engine.view());engine.invest(allocation);rewind.push(before);refresh(prose(engine.view())===text?before.state.readingPosition.offset:0);persist();}
  function saveSlot(n,name){if(!Number.isInteger(n)||n<1||n>30)throw Error('Invalid save slot.');write('-slot-'+n,{state:snapshot(),name:String(name||'').slice(0,80),preview:pages[engine.snapshot().page]?.trim().slice(0,200)||'',bookStarts:Object.fromEntries([2,3].map(b=>[b,read('-book'+b+'-start')])),savedAt:new Date().toISOString()});}
  function restartBook(){const b=E.location(engine.snapshot().id).book;if(b===1){start();return;}const s=read('-book'+b+'-start');if(!s)throw Error('This save has no recorded book start. Use a named save or test chapter start.');jump(s,{checkpoint:true});if(b===2)storage.removeItem(key+'-book3-start');}
  return {engine,key,test,collection,rewind,read,write,refresh,persist,snapshot,start,load,jump,step,choose,back,invest,saveSlot,restartBook,takeAwards:()=>pendingAwards.splice(0),pages:()=>pages,isStarted:()=>started,setStarted:v=>{started=v},record,BASE};
 }
 const api={create,paginate,prose,BASE};if(node)module.exports=api;else root.MagiumTextModel=api;
})(typeof globalThis!=='undefined'?globalThis:this);
