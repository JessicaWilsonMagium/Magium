/* Bounded rewind within the current branch; no artwork or audio in history. */
(function(root){
 'use strict';
 const clone=value=>JSON.parse(JSON.stringify(value));
 function isContinue(view){
  if(view.finished||view.dead||view.choices.length!==1)return false;
  const choice=view.choices[0];
  return (!choice.special||choice.special==='checkpoint_save')&&/^(?:Continue|(?:Go to )?Next chapter|Proceed towards book [23])$/i.test(choice.text.trim());
 }
 function create({maxEntries=200,maxBytes=2*1024*1024}={}){
  let entries=[],bytes=0;
  function clear(){entries=[];bytes=0;}
  function push(record){
   const copy=clone(record),size=new TextEncoder().encode(JSON.stringify(copy)).length;
   if(size>maxBytes){clear();return false;}
   entries.push({record:copy,size});bytes+=size;
   while(entries.length>maxEntries||bytes>maxBytes)bytes-=entries.shift().size;
   return true;
  }
  function pop(){const entry=entries.pop();if(!entry)return null;bytes-=entry.size;return clone(entry.record);}
  return {push,pop,clear,canBack:()=>entries.length>0,usage:()=>({entries:entries.length,bytes})};
 }
 const api={create,isContinue};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MagiumRewind=api;
})(typeof window!=='undefined'?window:globalThis);

