/* Independent per-book requirements; intentionally inactive for Flori's testing. */
(function(root){
 const required=25;
 function status(catalog,earned,book,enabled=false){const set=new Set(earned),awards=catalog.filter(a=>a.book===book),count=awards.filter(a=>set.has(a.id)).length;return {book,nextBook:book+1,required,total:awards.length,earned:count,remaining:Math.max(0,required-count),eligible:count>=required,enforced:enabled,canContinue:!enabled||count>=required};}
 const api={status,required};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MagiumTextAccess=api;
})(typeof globalThis!=='undefined'?globalThis:this);
