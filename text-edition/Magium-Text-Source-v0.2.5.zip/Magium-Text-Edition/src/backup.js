/* Portable player-controlled backups. No account or automatic cloud service. */
(function(root){
 'use strict';
 const KEY='magium-text-edition-v1',FORMAT='magium-interactive-backup',LIMIT=2*1024*1024;
 const suffixes=['-auto','-checkpoint','-manual','-book2-start','-book3-start',...Array.from({length:30},(_,i)=>'-slot-'+(i+1))];
 const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const fail=message=>{throw Error(message)};
 function safe(value,depth=0){
  if(depth>12)fail('This backup is too deeply nested.');
  if(value===null||typeof value==='boolean'||typeof value==='string')return;
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Invalid number in backup.');return}
  if(Array.isArray(value)){if(value.length>10000)fail('Backup list is too large.');for(const item of value)safe(item,depth+1);return}
  if(!plain(value))fail('Invalid backup content.');
  for(const [key,item]of Object.entries(value)){if(['__proto__','prototype','constructor'].includes(key))fail('Invalid backup field.');safe(item,depth+1)}
 }
 function validateRecord(record,validateState){
  if(!plain(record))fail('Invalid saved game in backup.');
  const state=record.state||record;
  if(!plain(state)||state.version!==1||typeof state.id!=='string'||!Number.isInteger(state.page)||state.page<0||!plain(state.vars)||!Array.isArray(state.achievements)||state.achievements.some(x=>typeof x!=='string')||typeof state.finished!=='boolean')fail('Invalid saved game in backup.');
  if(state.id.length>200||state.page>100000)fail('Invalid saved reading position.');
  const cap=state.vars.v_max_stat;if(![3,4].includes(cap)||!Number.isInteger(state.vars.v_available_points)||state.vars.v_available_points<0)fail('Invalid saved stats.');
  for(const stat of ['strength','toughness','agility','reflexes','hearing','perception','ancient_languages','combat_technique','premonition']){const n=state.vars['v_'+stat];if(!Number.isInteger(n)||n<0||n>cap)fail('Invalid saved stats.');}
  if(record.state){if(record.name!==undefined&&(typeof record.name!=='string'||record.name.length>80))fail('Invalid save name.');if(record.preview!==undefined&&typeof record.preview!=='string')fail('Invalid save preview.');if(record.savedAt!==undefined&&(typeof record.savedAt!=='string'||!Number.isFinite(Date.parse(record.savedAt))))fail('Invalid save timestamp.');}
  validateState(state);
 }
 function validateAwards(record){if(!plain(record)||record.version!==1||!Array.isArray(record.earned)||record.earned.some(id=>typeof id!=='string'||!/^v_ac_[a-zA-Z0-9_]+$/.test(id)))fail('Invalid achievement collection.');}
 function parse(text,validateState){
  if(typeof text!=='string'||new TextEncoder().encode(text).length>LIMIT)fail('Backup is too large (maximum 2 MB).');
  let data;try{data=JSON.parse(text)}catch{fail('This file is not a valid Magium backup.')}
  safe(data);
  if(!plain(data)||data.format!==FORMAT||data.version!==1||!plain(data.records)||typeof data.createdAt!=='string'||!Number.isFinite(Date.parse(data.createdAt)))fail('This is not a supported Magium backup.');
  const keys=Object.keys(data.records),allowed=[...suffixes,'-achievements'];
  const base=['-auto','-checkpoint','-manual','-achievements'];
  const count=keys.filter(k=>k.startsWith('-slot-')).length;
  if(![10,20,30].includes(count)||keys.some(k=>!allowed.includes(k))||base.some(k=>!Object.hasOwn(data.records,k))||Array.from({length:count},(_,i)=>'-slot-'+(i+1)).some(k=>!Object.hasOwn(data.records,k)))fail('Backup has missing or unexpected records.');
  for(const suffix of suffixes)if(!Object.hasOwn(data.records,suffix))data.records[suffix]=null;
  for(const suffix of suffixes){const record=data.records[suffix];if(record!==null)validateRecord(record,validateState)}
  if(data.records['-achievements']!==null)validateAwards(data.records['-achievements']);
  return data;
 }
 function recoverAwards(data,catalog=[],live=null){
  const earned=new Set(data.records['-achievements']?.earned||[]);
  for(const id of live?.earned||[])if(typeof id==='string'&&/^v_ac_[a-zA-Z0-9_]+$/.test(id))earned.add(id);
  for(const suffix of suffixes){const record=data.records[suffix],state=record?.state||record;if(!state)continue;
   for(const award of catalog)if(state.achievements.includes(award.title)||state.vars[award.id]===2||(award.id==='v_ac_ch6_immersion'&&state.vars[award.id]===1))earned.add(award.id);
  }
  data.records['-achievements']={version:1,earned:[...earned]};return data;
 }
 function create(storage,validateState,chapters,options={}){
  const records={};
  for(const suffix of [...suffixes,'-achievements']){const raw=storage.getItem(KEY+suffix);try{records[suffix]=raw===null?null:JSON.parse(raw)}catch{fail('A saved record could not be read. Nothing has been changed.')}}
  const data={format:FORMAT,version:1,createdAt:new Date().toISOString(),book:1,chapters,records};
  recoverAwards(data,options.catalog,options.collection);
  const text=JSON.stringify(data);parse(text,validateState);return text;
 }
 function summary(data){return {slots:suffixes.filter(s=>s.startsWith('-slot-')&&data.records[s]!==null).length,automatic:data.records['-auto']!==null,checkpoint:data.records['-checkpoint']!==null,legacy:data.records['-manual']!==null,awards:new Set(data.records['-achievements']?.earned||[]).size};}
 function restore(storage,data,validateState){
  // Revalidate at the write boundary, before reading or changing storage.
  data=parse(JSON.stringify(data),validateState);
  const before=new Map(),next=new Map();
  for(const suffix of [...suffixes,'-achievements'])before.set(KEY+suffix,storage.getItem(KEY+suffix));
  for(const suffix of suffixes)next.set(KEY+suffix,data.records[suffix]===null?null:JSON.stringify(data.records[suffix]));
  let existing;try{existing=JSON.parse(before.get(KEY+'-achievements'));validateAwards(existing)}catch{existing={version:1,earned:[]}}
  const earned=[...new Set([...existing.earned,...(data.records['-achievements']?.earned||[])])];
  next.set(KEY+'-achievements',JSON.stringify({version:1,earned}));
  // A journal allows recovery if the app closes between localStorage writes.
  const journalKey=KEY+'-backup-journal',journal=JSON.stringify({version:1,before:Object.fromEntries(before)});
  try{storage.setItem(journalKey,journal)}catch{fail('There is not enough storage to restore safely. Your saves are unchanged.')}
  try{
   for(const [key,value]of next){if(value===null)storage.removeItem(key);else storage.setItem(key,value)}
   storage.removeItem(journalKey);
  }catch{
   let recovered=true;for(const key of before.keys())try{storage.removeItem(key)}catch{recovered=false}
   for(const [key,value]of before)try{if(value!==null)storage.setItem(key,value)}catch{recovered=false}
   if(recovered){try{storage.removeItem(journalKey)}catch{}fail('Import failed. Your previous saves were restored.')}
   fail('Import was interrupted. Restart the app to recover your previous saves.');
  }
 }
 function recover(storage){
  const journalKey=KEY+'-backup-journal',raw=storage.getItem(journalKey);if(raw===null)return;
  let journal;try{journal=JSON.parse(raw)}catch{fail('A backup recovery record could not be read.')}
  const allowed=[...suffixes,'-achievements'].map(s=>KEY+s);
  if(journal?.version!==1||!plain(journal.before)||(Object.keys(journal.before).length!==allowed.length&&!(Object.keys(journal.before).length===allowed.length-1&&!Object.hasOwn(journal.before,KEY+'-book2-start')))||Object.keys(journal.before).some(k=>!allowed.includes(k)||!(journal.before[k]===null||typeof journal.before[k]==='string')))fail('Invalid backup recovery record.');
  for(const key of allowed)storage.removeItem(key);
  for(const [key,value]of Object.entries(journal.before)){if(value!==null)storage.setItem(key,value)}
  storage.removeItem(journalKey);
 }
 const api={KEY,FORMAT,LIMIT,suffixes,parse,create,summary,restore,recover,recoverAwards};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MagiumBackup=api;
})(typeof window!=='undefined'?window:globalThis);

