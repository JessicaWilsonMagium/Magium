/* Generated wrappers. Vendored upstream bodies below are byte-for-byte unchanged. */
(function(root){
const node=typeof module!=='undefined'&&module.exports, ejs=root.ejs||(node?require('ejs'):null);
const locale={"outlineMenuButtonText":"MAIN MENU","outlineStatsButtonText":"STATS","mainAchievementUnlockedText":"ACHIEVEMENT UNLOCKED","mainCheckpointReachedText":"[ Checkpoint reached: Game saved. ]","mainHeaderTemplate":"Book&nbsp;<%= book %> - Chapter&nbsp;<%= chapter %>","mainStatSuccessTemplate":"[ <%= variable %> check successful - level <%= value %>  ]","mainStatFailedTemplate":"[ <%= variable %> check failed - level <%= value %>  ]","mainStatDeviceLockedText":"[ Stat device locked - check failed ]","menuBackToGameText":"Back to game","menuNewGameText":"New game / Restart book","menuLoadCheckpointText":"Load from last checkpoint","menuSaveLoadText":"Save / Load game","menuImportExportText":"Import/Export menu","menuAchievementsText":"Achievements","menuSettingsText":"Settings","menuAboutText":"About","menuHeaderText":"Menu","achievementsMenuBookTemplate":"Book <%= num %>","achievementsMenuHeaderText":"Achievements","achievementsMenuChapterTemplate":"Chapter <%= num %>","savesSaveText":"Save","savesLoadText":"Load","savesExportText":"Export","savesImportText":"Import","savesImportCancelText":"Cancel","savesExportAchievementsText":"Export achievements","savesImportAchievementsText":"Import achievements","savesExportAllText":"Export all","savesImportAllText":"Import all","savesModalText":"Paste your save below to import it.","savesAchievementsModalText":"Paste your achievement save below to import it.","savesAllModalText":"Paste your save below to import it.<br/>WARNING: this will replace all your existing saves and achievements.","savesReturnToGameText":"Return to game","savesExplanationText":"Select a savegame slot from below.","savesHeaderText":"Save files","statsAuraHardeningText":"Aura hardening","statsMagicalSenseText":"Magical sense","statsBluffText":"Bluff (aura concealement)","statsCombatTechniqueText":"Combat technique","statsAncientLanguagesText":"Ancient languages","statsObservationText":"Observation","statsPremonitionText":"Premonition","statsHearingText":"Hearing","statsReflexesText":"Reflexes","statsSpeedText":"Speed","statsToughnessText":"Toughness","statsStrengthText":"Strength","statsAvailablePointsText":"Available points","statsMagicalKnowledgeText":"Magical knowledge","statsMagicalPowerText":"Magical power","statsCancelText":"Cancel changes","statsConfirmText":"Confirm Changes","statsReturnToGameText":"Return to game","statsHeaderText":"Stats","statsIntroductionText":"Since this is the first time you're entering the stats screen, here is a short introduction. <br/> <br/> This is where you can spend your available points by pressing on any one of the stats from the Stat screen. Upon each press, you will spend one available point in order to gain one level in that stat.<br/> <br/> Your number of available points is shown at the top of the Stat screen.<br/> <br/> You can cancel or confirm your changes by using the buttons at the bottom of the screen.<br/> <br/> Every once in a while, the game will check to see if your stats are high enough to perform a certain action in a scene. If your stat level is not high enough you will fail your check, which will be announced by a red message on top of your screen. A succesful stat check will be shown in green. Here are two examples:<br/> <br/>","statsIntroductionButton":"Continue to stats screen","settingsLanguageText":"Change language","settingsOriginalLightThemeText":"Original Light Theme","settingsOriginalDarkThemeText":"Original Dark Theme","settingsCatppuccinLightThemeText":"Catppuccin Light Theme","settingsCatppuccinDarkThemeText":"Catppuccin Dark Theme","settingsCheatModeText":"Cheat mode","settingsCheatModeModalText":"This option will give you an amount of stats point sufficient to maximize all stats. <br> This will affect your current save irreversibly. <br> Do you wish to continue?<br>","settingsBackToMenuText":"Back to menu","settingsHeaderText":"Settings","languageHeaderText":"Language selection","languageBackToSettingsText":"Back to settings","aboutIntroText":" Magium is a Choose Your Own Adventure game initially written and developed by Cristian Mihailescu. <br> Following the passing of the author in August 2024, this version of a game was developed in order to preserve the legacy of the game and allow for the community to continue the development of the game in the future, in accordance with the will of the family of the author.","aboutSocialsText":"If you want to join the community:","aboutDevelopementText":"If you want to participate in the development effort:","aboutHeaderText":"About","localeYes":"Yes","localeNo":"No"};
const engineEjs=Object.assign({},ejs,{renderFile:(_path,locals)=>locals});
function utilsModule(require,module,exports){
const ejs = require("ejs");

// List of stat variables ; used to check which variables should trigger a stat check display
const stats_variables = [
    "v_strength",
    "v_toughness",
    "v_agility", // Speed
    "v_reflexes",
    "v_hearing",
    "v_perception", // Observation
    "v_ancient_languages",
    "v_combat_technique",
    "v_premonition",
    "v_bluff",
    "v_magical_sense",
    "v_aura_hardening",
    "v_magical_power", // Currently, not utilized
    "v_magical_knowledge", // Currently, not utilized
];

/** Builds the header text from the scene id. This leverages a header template
 * defined for each locale.
 *
 * @param {str} sceneId - Id of the relevant scene. Should look like "B2-Ch07a-Intro".
 * @param {string} headerTemplate - EJS template representing the header text. Should have fields "book" and "chapter".
 * @returns {string} Header text. In English, this looks like "Book X - Chapter Y".
 * */
function getHeaderFromId(sceneId, headerTemplate) {
    const regex = /(B(?<book>[0-9]*)-)?Ch(?<chapter>[0-9]*)[a-c]?-.*$/;
    let result = regex.exec(sceneId)
    if (result) {
        let book = result.groups["book"] ? result.groups["book"] : "1";
        let chapter = parseInt(result.groups["chapter"]);
        return ejs.render(headerTemplate, { "book": book, "chapter": chapter })
    }
}

/** Retrieves all the data associated to a given locale.
 *
 * @param {Object.<string, Object>} fullData - Object indexed by the locale keys; each field should in turn be an Object. This is normally imported from the data/<lang>/ui.json files.
 * @param {string} localeKey - Locale key. Will default to "en" if undefined.
 * @returns {Object} All data associated to the given locale.
 * */
function getLocaleData(fullData, localeKey) {
    let locale = localeKey ? localeKey : "en"
    return Object.assign({}, fullData[locale])
}

/** Computes whether a condition evaluates to true or false 
 * @param {string} entry - String representing the condition, e.g. "v_perception > 2" 
 * @param {Object.<string, number>} values - Object containing the values of the different variables; is used to query the value of the variable the condition is about 
 * @returns {boolean}
 * */
function apply_condition(entry, values) {
    if (!entry) {
        return true;
    }
    let match;
    if (entry == "True") {
        return true;
    } else if (
        (match = entry.match(
            /(?<varName>\w*) (?<condType><|>|>=|==|<=|!=) (?<value>[0-9]+)/,
        ))
    ) {
        var variable = match.groups.varName;
        var condType = match.groups.condType;
        var value = parseInt(match.groups.value);
        switch (condType) {
            case ">": return (values[variable] || 0) > value;
            case "<": return (values[variable] || 0) < value;
            case "<=": return (values[variable] || 0) <= value;
            case ">=": return (values[variable] || 0) >= value;
            case "!=": return (values[variable] || 0) != value;
            case "==": return (values[variable] || 0) == value;
        }
    } else {
        console.log("Condition fail");
        console.log(entry);
        return;
    }
}

/** Computes whether a collection of conditions evaluates to true or false.
 * It is assumed that the conditions are stored as an array of arrays, representing the DNF ("OR of ANDS") of the full condition. That is, every inner array represents an AND of all the conditions is contained, while the outer array is an OR.
 * @param {Array.<Array.<string>>} conditions - Array of array representing the conditions as described above.
 * @param {Object.<string, number>} values - Object containing the values of the different variables; is used to query the value of the variable the condition is about 
 * @returns {boolean}
 * */
function apply_conditions(conditions, values) {
    return (
        !conditions ||
        conditions.some((conds) =>
            conds.every((cond) => apply_condition(cond, values)),
        )
    );
}

/** Capitalizes the first letter of the given string
 *
 * @param {string} val - String to capitalize
 * @returns {string} Capitalized string
 *
 * */
function capitalizeFirstLetter(val) {
    return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}

/** Transforms the name of a stat variable to the key used to access the localeData.
 *
 * @param {string} varName - Name of the stat variable, e.g "v_premonition"
 * @returns {string} Key of the stat in the localeData, e.g statsPremonitionText
 * */
function varToStat(varName) {
    let statName;
    if (varName == "v_agility") {
        statName = "Speed";
    }
    else if (varName == "v_perception") {
        statName = "Observation";
    } else {
        statName = (
            varName.slice(2).split("_").map(capitalizeFirstLetter).join("")
        );
    }
    return "stats" + statName + "Text";
}

/** Parses a string representing a stat check. 
 * This is specifically made to get the needed representation of the stat check string; choices depending on the stat check are handled by apply_condition(s). It returns undefined if given a condition that is not on a stat variable. Here it is assumed that the given condition is true.
 *
 * @param {string} condition - String representing the condition, e.g. "v_perception > 2".
 * @returns {{ variable: string, value: number, success: boolean}}
 * */
function parseStatCheck(condition) {
    let match;
    if (
        (match = condition.match(
            /(?<varName>\w*) (?<condType><|>|>=|==|<=|!=) (?<value>[0-9]+)/,
        ))
    ) {
        var variable = match.groups.varName;
        var condType = match.groups.condType;
        var value = parseInt(match.groups.value);
    } else {
        console.log("Stat check parsing fail");
        console.log(condition);
        return;
    }
    // Handle the case where you lock your stat device at the beginning of book 3
    if (variable === "v_b3_ch1_unlock" && condType === "==" && value === 2) {
        return { variable: variable, value: value, success: false }
    }
    if (!stats_variables.includes(variable)) {
        return;
    }

    let success;
    if (condType == "<") {
        success = false;
    } else if (condType == "==" && value == 0) {
        success = false;
        value = 1;
    } else if (condType == ">=" || (condType == "==" && value != 0)) {
        success = true;
    } else if (condType == ">") {
        success = true;
        value += 1;
    } else {
        console.log("Unmatched condition type", condType);
    }
    return { variable: varToStat(variable), value: value, success: success };
}

/** Extracts the stats check from the variables set by the scene.
 *
 * @param {Array.<Object>} setVariables - 
 * @param {Object.<string, number>} values - Actual values of the variables. Used to check which set variables should be considered.
 * @param {Object.<string, string>} localeData - Locale data, as can be obtained with getLocaleData.
 * */
function statChecksToDisplay(setVariables, values, localeData) {
    let newStatChecks = [];
    let setVariable;
    for (setVariable of setVariables) {
        if (!setVariable.conditions) {
            continue;
        } else {
            let conditionGroups = setVariable.conditions.filter((conds) =>
                conds.every((cond) => apply_condition(cond, values)),
            );
            let conditionGroup, condition, statCheck;
            for (conditionGroup of conditionGroups) {
                for (condition of conditionGroup) {
                    if ((statCheck = parseStatCheck(condition))) {
                        statCheck.variable = statCheck.variable == "v_b3_ch1_unlock" ? statCheck.variable : localeData[statCheck.variable];
                        newStatChecks.push(JSON.stringify(statCheck));
                    }
                }
            }
        }
    }
    newStatChecks = [...new Set(newStatChecks)].map(JSON.parse);
    // If stat device locked, do not display other checks
    if (newStatChecks.some((statCheck) => statCheck.variable == "v_b3_ch1_unlock")) {
        newStatChecks = newStatChecks.filter((statCheck) => statCheck.variable == "v_b3_ch1_unlock")
    }
    return newStatChecks
}


module.exports = {
    capitalizeFirstLetter,
    getHeaderFromId,
    getLocaleData,
    apply_conditions,
    statChecksToDisplay,
    varToStat,
};

}
const u={exports:{}};utilsModule(()=>engineEjs,u,u.exports);
function rendererModule(require,module,exports,process){
const ejs = require("ejs");
const {
    getHeaderFromId,
    apply_conditions,
    statChecksToDisplay,
} = require("./utils.js");
const path = require("path");
const fs = require("fs");

let dirName;
if (process.resourcesPath && fs.existsSync(path.join(process.resourcesPath, "app"))) {
    dirName = path.join(process.resourcesPath, "app")
}
else {
    dirName = process.cwd();
}
const templateDirName = path.join(dirName, "templates");

/** Renders a given page ; if the request is from HTMX, it will only render the
 * relevant content, else it will render the outline of the page (triggering an
 * extra callback).
 *
 * @param {object} req - Object representing the request (as used in Express)
 * @param {function(object)} callback - Function for rendering the inner content, taking in a request object.
 * @param {string} [header=""] - Header text
 * @returns {string} Renderered HTML.
 * */
function renderFull(req, callback, header = "") {
    if (req.get("HX-Request")) {
        return callback(req);
    } else {
        return ejs.renderFile(path.join(templateDirName, "outline.ejs"), Object.assign({
            header: header,
            path: req.path,
        }, req.data));
    }
}

/** Returns a function that renders a given page (using renderFull) and sends 
 * back the result. This function is expected to be given to Express.
 *
 * @param {function(object)} callback - Function for rendering the inner content, taking in a request object.
 * @param {string} headerKey - Key for retrieving the header text in req.data.
 * @returns {function(object, object)} Function to pass to Express.
 * */
function renderThenSend(callback, headerKey) {
    return (req, res) => renderFull(req, callback, req.data[headerKey]).then(
        (rendered) => res.send(rendered),
    );
}

function renderScene(req) {
    const id = req.body.v_current_scene
        ? req.body.v_current_scene
        : "Ch1-Intro1";
    let cookieData = Object.assign({}, req.body);
    let sceneData = Object.assign({}, req.data[id]);
    sceneData.setVariables = sceneData.setVariables.filter((setVariable) =>
        apply_conditions(setVariable.conditions, cookieData),
    );
    sceneData.setVariables.forEach(
        (setVariable) => (cookieData[setVariable.name] = setVariable.value),
    );
    sceneData.choices = sceneData.choices.filter(
        (choice) => apply_conditions(choice.conditions, cookieData),
    );
    sceneData.paragraphs = sceneData.paragraphs.filter(
        (paragraph) => apply_conditions(paragraph.conditions, cookieData),
    );
    sceneData.statChecks = statChecksToDisplay(
        sceneData.setVariables.concat(sceneData.paragraphs, sceneData.choices),
        cookieData,
        req.data,
    );
    // This particular scene checks for the stats for Average Joe purposes 
    if (id == "B3-Ch04a-Introduction2") {
        sceneData.statChecks = [];
    }

    sceneData.achievements = sceneData.achievements.filter(
        (achievement) => cookieData[achievement.variable] === "1"
    );
    // This achievement can show up in any scene
    if (cookieData["v_ac_b3_ch9_prize"] == "1") {
        sceneData.achievements.push({ "text": "Consolation prize", "variable": "v_ac_b3_ch9_prize" })
    }
    sceneData.checkpoint = sceneData.choices.some(
        (choice) => choice.setVariables["v_checkpoint_rich"] === "0",
    );
    let data = Object.assign({}, { id: id, header: getHeaderFromId(id, req.data["mainHeaderTemplate"]), scene: sceneData, "ejs": ejs }, cookieData, req.data);
    return ejs.renderFile(path.join(templateDirName, "main.ejs"), data);
}

function renderStats(req) {
    let data = Object.assign({}, req.data, {
        "maximized":
            (req.body.v_current_scene || "") === "Ch6-Eiden-vs-dragon" &&
            (req.body.v_maximized_stats_used || 0) === "1",
        "stats_intro_seen": req.cookies.stats_intro_seen,
        "ejs": ejs,
    }, req.body);
    return ejs.renderFile(path.join(templateDirName, "stats.ejs"), data);
}

function renderMenu(req) {
    return ejs.renderFile(
        path.join(templateDirName, "menu.ejs"),
        req.data,
    );
}

function renderSettings(req) {
    return ejs.renderFile(
        path.join(templateDirName, "settings.ejs"),
        Object.assign({}, req.body, req.data),
    );
}

function renderLanguage(req, locales) {
    return ejs.renderFile(
        path.join(templateDirName, "language.ejs"),
        Object.assign({}, req.data, { "locales": locales }),
    );
}

function renderAchievementsMenu(req) {
    const bookCount = Object.keys(req.data.achievements).length;
    return ejs.renderFile(
        path.join(templateDirName, "achievements_menu.ejs"),
        Object.assign({}, req.data, req.body, { "ejs": ejs, "bookCount": bookCount }),
    );
}

function renderAchievementsMenuBook(req) {
    const achievementsData = req.data.achievements[parseInt(req.params.id)];
    return ejs.renderFile(
        path.join(templateDirName, "achievements_menu_book.ejs"),
        Object.assign({}, req.data, { achievements: achievementsData, ejs: ejs }),
    );
}

function renderAchievementsMenuChapter(req) {
    const achievementsData = req.data.achievements[parseInt(req.params.idBook)][`b${req.params.idBook}ch${req.params.idChapter}`];
    return ejs.renderFile(
        path.join(templateDirName, "achievements_menu_chapter.ejs"),
        Object.assign({}, req.body, req.data, { achievements: achievementsData }),
    );
}

function renderSaves(req) {
    let saveData = {};
    Object.entries(req.body).forEach(function (entry) {
        saveData[entry[0]] = { date: entry[1].date, name: entry[1].name };
    });
    let data = Object.assign({}, req.cookies, { saveData: saveData }, req.data);
    return ejs.renderFile(path.join(templateDirName, "saves.ejs"), data);
}

function renderSavesByPage(req, page) {
    let saveData = {};
    Object.entries(req.body).forEach(function (entry) {
        if (entry[1]) {
            saveData[entry[0]] = { date: entry[1].date, name: entry[1].name };
        }
    });
    let data = Object.assign({}, req.cookies, {
        saveData: saveData,
        page: parseInt(page),
    }, req.data);
    return ejs.renderFile(path.join(templateDirName, "saves.ejs"), data);
}

function renderAbout(req) {
    return ejs.renderFile(
        path.join(templateDirName, "about.ejs"),
        Object.assign({}, req.cookies, req.data),
    );
}

module.exports = {
    renderAbout,
    renderAchievementsMenu,
    renderAchievementsMenuBook,
    renderAchievementsMenuChapter,
    renderLanguage,
    renderMenu,
    renderScene,
    renderSettings,
    renderStats,
    renderSaves,
    renderSavesByPage,
    renderThenSend,
}

}
const r={exports:{}};rendererModule(name=>name==='ejs'?engineEjs:name==='./utils.js'?u.exports:name==='path'?{join:(...p)=>p.join('/')}:name==='fs'?{existsSync:()=>false}:null,r,r.exports,{cwd:()=>'',resourcesPath:null});
function storageBridge(initial={}){
 const copy=x=>JSON.parse(JSON.stringify(x));let stores={currentState:copy(initial.currentState||{}),achievements:copy(initial.achievements||{})};
 const readSaveFromLocalStorage=id=>copy(stores[id]||{}),writeSaveToLocalStorage=(id,value)=>{stores[id]=copy(value)};
 let locals,statElements={};const window={scroll(){},location:{pathname:'/stats',reload(){}}},document={addEventListener(){},getElementById:id=>statElements[id]||null};
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) {
      return parts.pop().split(';').shift();
    }
    return null;
}

function storeItem(key,value,storageId) {
    let data = readSaveFromLocalStorage(storageId);
    value = value.toString();
    if (value.startsWith("+")){
        data[key] = parseInt(data[key] || 0) + parseInt(value.slice(1));
    }
    else if (value.startsWith("-")){
        data[key] = parseInt(data[key] || 0) - parseInt(value.slice(1));
    }
    else {
        data[key] = value;
    }
    if (key == "v_ac_b3_ch9_consolation" && data[key] == 5) {
        data["v_ac_b3_ch9_prize"] = 1;
    }
    writeSaveToLocalStorage(storageId,data);
}

function storeVariable(key,value) {
    if (key.startsWith("v_ac_")){
        let data = readSaveFromLocalStorage("achievements");
        if (data[key] != 2) {
            storeItem(key,value,"achievements");
        }
    }
    else {
        storeItem(key,value,"currentState");
    }
}


function initializeFontSizeSlider() {
    const fontSizeElem = document.getElementById("fontSize");
    const currentFontSize = document.documentElement.style.fontSize;
    if (currentFontSize) {
        const currentFontSizePx = parseFloat(currentFontSize.slice(0,-2));
        if (currentFontSizePx) {
            fontSizeElem.value = currentFontSizePx / 16;
            fontSizeElem.classList.remove("js-loading");
            return;
        }
    }
    fontSizeElem.value = 1;
    fontSizeElem.classList.remove("js-loading");
}

function initializeThemeText() {
    const savedTheme = localStorage.getItem("theme") || (checkIsDarkSchemePreferred() ? Theme.DARK : Theme.LIGHT);
    document.getElementById("themeDropdown").value = savedTheme;
}

function updateFontSize() {
    const fontSizeElem = document.getElementById("fontSize");
    const fontSize = parseFloat(fontSizeElem.value);
    document.documentElement.style.setProperty("font-size",`${16*fontSize}px`);
    document.cookie = `fontsize=${16*fontSize}px`;
}

function navigateTo(url) {
    window.location.href = url;
}

function setResponseVariables(response) {
  window.scroll(0, 0);

  for (const [key, value] of Object.entries(response.setVariables)) {
      storeVariable(key,value)
  }
}

async function copyToClipboard(textToCopy) {
    // Navigator clipboard api needs a secure context (https)
    if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(textToCopy);
    } else {
        // Use the 'out of viewport hidden text area' trick
        const textArea = document.createElement("textarea");
        textArea.value = textToCopy;
            
        // Move textarea out of the viewport so it's not visible
        textArea.style.position = "absolute";
        textArea.style.left = "-999999px";
            
        document.body.prepend(textArea);
        textArea.select();

        try {
            document.execCommand('copy');
        } catch (error) {
            console.error(error);
        } finally {
            textArea.remove();
        }
    }
}



// import utils.js // Perhaps a better way to specify the dependence of the file on utils.js

// Check if some of the stats are undefined.
// If they are, update every stat cookie with the default value 0, and reload the page.

const stats_names = ["available_points", "strength", "toughness", "agility", "reflexes",
    "hearing", "perception", "ancient_languages", "combat_technique", "premonition",
    "bluff", "magical_sense", "aura_hardening", "magical_power", "magical_knowledge",
    "max_stat"]


function initStats(event) {
    const path = window.location.pathname;
    const page = path.split("/").pop();
    if (page != "stats") {
        return;
    }
    locals = readSaveFromLocalStorage("currentState");

    var reload = false;
    stats_names.forEach(function(stat) {
        const stat_var = "v_" + stat;
        const value = locals[stat_var];
        if (value === null || value === undefined) {
            if (stat_var === 'v_max_stat') {
                locals[stat_var] = 3;
            } else {
                locals[stat_var] = 0;
            }
            reload = true;
        }
    });
    if (reload) {
        writeSaveToLocalStorage("currentState",locals);
        window.location.reload();
    }
}
document.addEventListener("htmx:afterSwap", initStats)
document.addEventListener("DOMContentLoaded", initStats)

function updateStat(stat_id) {
    const available_points = parseInt(document.getElementById("available_points_value").innerHTML);
    const current_val = parseInt(document.getElementById(stat_id + "_value").innerHTML);
    const max_val = parseInt(document.getElementById(stat_id + "_max").innerHTML);

    if ((current_val >= max_val) || (available_points <= 0)) { return; }
    document.getElementById("available_points_value").innerHTML = available_points - 1;
    document.getElementById(stat_id + "_value").innerHTML = current_val + 1;
    document.getElementById(stat_id).className = "stat-field updated";
}

function confirmStats() {
    let data = readSaveFromLocalStorage("currentState");
    for (const stat_name of stats_names) {
        const element = document.getElementById(stat_name + "_value");
        if (element) {
            data["v_" + stat_name] = parseInt(element.innerHTML);;
        }
    }
    writeSaveToLocalStorage("currentState",data);
    // Refresh the page to reflect the changes
    window.location.reload();
}

 // Compatibility shim: the consolation variable is a counter, not an awarded badge.
 const upstreamStoreVariable=storeVariable;
 storeVariable=function(key,value){if(key==='v_ac_b3_ch9_consolation')return storeItem(key,value,'achievements');return upstreamStoreVariable(key,value);};
 return {storeVariable,setResponseVariables,read:()=>copy(stores),replace:value=>{stores=copy(value)},initializeStats:()=>initStats(),confirmAllocation:values=>{initStats();statElements={};for(const [key,value]of Object.entries({...stores.currentState,...values}))if(key.startsWith('v_'))statElements[key.slice(2)+'_value']={innerHTML:String(value)};confirmStats();statElements={};}};
}
function renderer(data){const requestData=Object.assign({},data,locale);return (body,sceneOverride)=>r.exports.renderScene({body,data:sceneOverride?Object.assign({},requestData,{[body.v_current_scene]:sceneOverride}):requestData});}
const api={renderer,storageBridge,conditions:u.exports.apply_conditions,locale};if(node)module.exports=api;else root.MagiumOriginal=api;
})(typeof globalThis!=='undefined'?globalThis:this);
