/* Presentation only. No engine, storage, awards or save APIs are used here. */
(function(root){
 'use strict';
 function isActive(state){return state?.id==='Ch6-Eiden-vs-dragon'&&Number(state.vars?.v_maximized_stats_used)===1;}
 function create({onFrame,onDone=()=>{},now=()=>Date.now(),schedule=(fn,ms)=>setTimeout(fn,ms),cancel=id=>clearTimeout(id),startValue=10,stepMs=1500}){
  let timer=null,started=0,generation=0,running=false;
  function stop(){running=false;generation++;if(timer!==null)cancel(timer);timer=null;}
  function start(){stop();running=true;started=now();const current=generation;
   function tick(){if(!running||current!==generation)return;timer=null;const value=Math.max(0,startValue-Math.floor(Math.max(0,now()-started)/stepMs));onFrame(value);if(!running||current!==generation)return;if(value===0){running=false;onDone();return;}timer=schedule(tick,Math.max(1,stepMs-((now()-started)%stepMs)));}
   tick();
  }
  return {start,stop,isRunning:()=>running};
 }
 const api={isActive,create};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MagiumTemporaryStats=api;
})(typeof globalThis!=='undefined'?globalThis:this);
