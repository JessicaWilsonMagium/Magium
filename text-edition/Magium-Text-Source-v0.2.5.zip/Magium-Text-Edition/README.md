# Magium Text Edition — 0.2.5

Public text-only build of Cristian Mihailescu's original interactive Books 1–3,
with Thuiop's execution routines and our reading interface. All 34 chapters are
included. No illustrations or audio. No testing tools. Book progression is unlocked.

## Install and saves

Install Magium-Text-Edition-v0.2.5.apk as an update to Magium Text. Package, signer,
WebView origin and existing save keys are preserved. Press Resume or load a named
slot to continue. The Stats button stays disabled on the title screen until a run
is resumed or loaded, preventing the misleading zero stats found during testing.

The separate Magium Engine Test app and its testing saves remain independent.
Flori may continue playing that version. This build does not update the private
website. Export/import JSON transfers a copy of normal saves between editions.

Normal Back returns across pages and Continue, stopping at real choices. Next
changes to Choose above when a choice is required. There are 30 named save slots,
checkpoints, achievements, reading settings, backup export/import and portrait
flipping. All included books remain unlocked; the future 25-achievement settings
are present but disabled, as previously requested.

Read ADAPTER.md for the offline integration boundaries and legacy save
reconstruction limitations. This is a signed
public build prepared for distribution; the earlier 0.2.2 build is a Google Play internal-test draft; this 0.2.5 update has not been uploaded.

## Rebuild web files and run tests

Node 18+ and Python 3 are required. Install development dependencies and build:

```sh
npm ci
npm run build
npm test
npm run compare
```

The HTML in dist is self-contained. The APK packages individual bundled files
once. tools/build.cjs uses the unmodified vendored parser and embeds unchanged
upstream routine bodies in the documented offline wrappers. Vendored story and
runtime files are pinned; no network access is needed to run the game.

## Build Android

Requires Java 17, Android build-tools 36.0.0 and platform 36. Use the original
private key; set MAGIUM_STORE_PASS, MAGIUM_KEY_PASS and MAGIUM_KEY_ALIAS privately
in the environment. Never put their values in source or build commands.

```sh
python3 tools/build-android.py \
  --build-tools /path/to/android-sdk/build-tools/36.0.0 \
  --android-jar /path/to/android-sdk/platforms/android-36/android.jar \
  --keystore /private/path/test.keystore
npm run verify-apk
```

The native DEX is reused unchanged from the verified 0.1.3 text APK. It is a pinned
binary build input; this archive reproduces packaging rather than compilation of
that DEX. It retains the existing WebView, JSON picker and portrait sensor logic.
The Android package is org.magium.textedition, versionCode 7, versionName 0.2.5.
Signing materials are not included. Check VALIDATION.md and tests/ for evidence.
The final production APK itself has not yet been executed on a physical device.

The Full immersion falling-stat display is restored in Book 1 Chapter 6.
Only the displayed numbers animate; real stats and saves remain unchanged.
The experimental app also receives this same presentation module as 0.1.1-lab.

Current update: original Magium logo, default reading size 20 for fresh preferences, and read-only Magical power / Magical knowledge values controlled by the original v_b3_ch11_magic flag. Existing saved preferences survive. VN save compatibility claims removed. Target SDK 36; original native DEX and save identity retained. Android predictive Back is temporarily opted out as documented by Android, preserving the existing onBackPressed bridge. Phone install/update and Android 16 system Back appearance checks remain necessary.

Optional Play AAB: add --bundletool /path/to/bundletool-all.jar to the Android build command. Requires a full JDK including jarsigner and Android build-tools with aapt2. No upload occurs.

APK asset verification uses Python Pillow to verify that Android PNG processing preserves every logo pixel.

## Achievement appearance update — 19 October 2026

Version 0.2.5 / versionCode 7 restores the approved original-style black achievement outlines, orange titles, red crosses and green ticks. Warm paper uses cream; Dark green and Black use softer dark backgrounds. Original titles, descriptions, chapter grouping, unlock logic and all save identities remain unchanged.

Validation: 21 existing tests passed; all 136 cards rendered in all three themes with no state or localStorage mutation; packaged APK offline startup, saves and native bridge checks passed in jsdom; original signing certificate verified; signed AAB validated by bundletool 1.18.2. Nine rendered Chromium checks passed across all themes at widths 320, 390 and 736 px; cream and dark screenshots visually inspected. Phone visual acceptance remains pending.

## Book and chapter achievement menus

The achievement screen now opens with Book 1, Book 2 and Book 3. Each book opens a chapter menu with per-chapter counts. Chapter pages show at most five original-style cards; larger chapters have numbered pages. Back and Android Back return from cards to chapters, then books, then close. Escape follows the same hierarchy. The original 25-achievement target for Books 2 and 3 appears with the number remaining; all books remain unlocked during testing. No payments, leaderboards, Google achievement integration or promise of Book 4 is displayed.

Version 0.2.5 / code 7 changes presentation and navigation only. Core story, achievement collection, save keys, Android package, native DEX and signer are retained. Physical-phone appearance review is pending.

## Icon attribution update — 0.2.5

Original Magium icon artwork: “Magic Ball” by Agnes Landgraf (Wyonet).
https://www.deviantart.com/wyonet/art/Magic-ball-362647907
The in-game Credits and attribution documents identify the artist.
No new permission is claimed; confirmation for the new editions is pending.
