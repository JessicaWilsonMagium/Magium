# Magium — Text Edition

Story and original game: **Cristian Mihailescu**.
Text edition prepared with **Flori Dumitrescu**.

Cristian’s original source code was shared by his mother and sole heir, Flori Dumitrescu.
Radu Privantu created the open-source repository with her permission: https://github.com/raduprv/Magium
Original text and branching conditions extracted from Cristian’s Clickteam project by Thuiop.
JavaScript interpreter and web adaptation: Thuiop and contributors (MagiumJS).
This Android text edition uses their parser, interpreter and original stat/state
routines with an adapted reading interface and offline Android integration.
Story data, parser, interpreter, frontend state/stat routines, achievement metadata
and web port: Thuiop and contributors, https://github.com/thuiop/magium-dev
Pinned commit: 51f5aa9406c094e5133be2c7d69988296f86cfbc.
Original MIT licence retained verbatim in LICENSE and the in-game Credits menu.
Its copyright line spells the name Christian Mihailescu; player-facing credits
use Cristian Mihailescu.

EJS 3.1.10: Matthew Eernisse and contributors, https://ejs.co/ — Apache License 2.0.
Full notice in vendor/EJS-LICENSE, EJS-LICENSE.txt in the APK, and in-game Credits.

The offline adapter, reader and native wrapper
are additions to the upstream runtime. See ADAPTER.md for the exact boundaries.
No story illustrations, audio, external fonts, ads, analytics or purchases are bundled.
Original Magium icon artwork: “Magic Ball” by Agnes Landgraf (Wyonet).
Original artwork and usage terms: https://www.deviantart.com/wyonet/art/Magic-ball-362647907
Used on the title screen and Android launcher icon. Artwork rights are separate
from the software and story licences. Closing payment and future-release
references are historical prose and do not activate purchases or book gates.
