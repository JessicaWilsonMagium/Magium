# Version 0.2.9 verification

Visible Credits explicitly acknowledge the JavaScript interpreter and web adaptation
by Thuiop and contributors (MagiumJS). Original source extraction and all existing
licence notices remain.

All 21 existing regression checks pass. Packaged APK starts offline in jsdom at
the native app-assets origin. Credits opens with the interpreter credit and source
link, and closes without changing game state. Save/reload and backup bridge checks
pass. Native DEX, story data and runtime code are unchanged from 0.2.8.

APK is signed with the original certificate. AAB passes official bundletool
validation. VersionCode12, package org.magium.textedition, same origin and save keys.
Physical Android acceptance remains pending. No Play upload or tester invitation
was performed. Prior differential checks remain applicable because story and
execution code are unchanged; they are not exhaustive proof of every route.
